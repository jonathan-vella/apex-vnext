<a id="top"></a>

# Changelog

All notable changes to **APEX vNext** are documented in this file.

Release history is available through the repository's **Releases** tab. The
current repository version is recorded in [VERSION.md](VERSION.md).

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed

- Rebaseline product requirements, roadmap and supporting documentation around COE archetype reuse, conversational
  adaptation, ALZ-backed and standalone lab profiles, rich output quality and WSL2 without a devcontainer.
- Keep input efficiency simple and DRY without a token-baseline project; defer Agent Plugins and APEX MCP distribution
  decisions until feature completion. Document planned behavior and executable-control alignment separately from
  implemented commands, existing safety checks and historical qualification evidence.

## [0.10.0-next.5] — Preview

### Changed

- Architecture now requires a typed qualitative assessment of all five Azure Well-Architected pillars and an explicit
  Reviewer criterion receipt for each pillar. The Gate 2 package includes derived Python, SVG, and PNG views for
  Architecture, WAF status, priced cost breakdown, and cost uncertainty while retaining authoritative evidence tables.
- Architecture assumes regional service/SKU availability and sufficient quota; regional, zonal, deployment, restore,
  failover, and capacity checks are optional documentation rather than APEX validations or review findings. Explicit
  partial pricing is accepted documentation, and out-of-scope findings can be dismissed without revising Architecture.
- Interactive authoring agents can recover externalized task context through one bounded MCP reader; Architecture now
  receives exact output templates while APEX derives decision-manifest identity, artifact hashes, must-requirement
  traceability, and cost/SKU bindings. Partial estimates record missing retail meters explicitly while synthetic
  unpriced cost placeholders remain rejected.
- Requirements review can acknowledge business-owned obligations with a responsible role, allowing Azure architects
  to document GDPR, retention, workload-volume, and product-policy gaps without inventing rationale or expiry dates.
- Requirements now uses three adaptive panels with confirmed recommendations, workload-specific scale prompts,
  non-binding service candidates, and no duplicate IaC question. Pending four-round intake remains replayable.
- Requirements, Architecture, Plan, and Reviewer use stage-specific completion operations. Review findings return as a
  conversational decision panel; revision creates fresh stage evidence and permitted risk acceptance remains time-bound.
- Human `status` and `doctor` output is concise by default, with full detail under `--verbose` or `--json`.
- Runtime updates preserve immutable generations: existing runs stay pinned while future projects use the latest bundle.
- Published `@apexops/*` packages now include package-specific READMEs with installation, usage, and documentation
  links, verified as part of the release-tarball contract.

## [0.10.0-next.4] — Preview

### Changed

- Requirements now invokes the Reviewer task automatically in VS Code after accepted requirements are submitted.
- Gates 1 through 3 can be explicitly approved or rejected in chat; APEX records the local OS username as actor.
  Gate 4 remains recipient-bound and CLI-only.
- Planner completion is now atomic: APEX derives the canonical implementation-intent hash before binding and submitting
  the complete plan bundle.

## [0.10.0-next.3] — Preview

### Changed

- Requirements intake now asks retained-service constraints only for migration, modernization, and extension scenarios.
  Availability, backup, and disaster-recovery capabilities use selectable options, while exact RTO/RPO targets remain a
  distinct numeric decision.

## [0.10.0-next.2] — Preview

### Changed

- Restored reviewable, kernel-derived workflow packages across Requirements, Architecture, Planner, Operations,
  Reviewer, Validator, and the coordinator dashboard. Generated documents preserve human review without becoming a
  second authority source; all gate decisions remain explicit terminal ceremonies.

## [0.10.0-next.1] — Preview

### Fixed

- Packaged the APEX Azure MCP launcher as a release-tarball contract and defaulted its .NET child process to invariant
  globalization when ICU is unavailable. Consumers can override `DOTNET_SYSTEM_GLOBALIZATION_INVARIANT` when their
  environment provides ICU.

## [0.10.0-next.0] — Preview

This release line was extracted from a qualified vNext integration head in the
original APEX repository. The release contract was subsequently re-baselined;
prior qualification is retained as historical characterization. See
[docs/MIGRATION.md](docs/MIGRATION.md) for provenance.

### Changed

- Requirements now preserve structured business, non-functional, security, budget, regional, and candidate-service
  context in the accepted artifact. Acceptance materializes a reviewer-backed Gate 1 package under
  `agent-output/<project>/<run>/` with requirements, service rationale, SKU preferences, and challenger findings.
- APEX Requirements now runs an adaptive discovery workshop, offers candidate Azure services with rationale without
  making Architecture decisions, and directs the existing reviewer task through the human Gate 1 review ceremony.
- The APEX coordinator now handles an active-project replacement through MCP: it creates the supplied replacement
  first, then deletes the confirmed original only after creation succeeds.
- The APEX coordinator now delegates kernel requirements-intake questions to APEX Requirements instead of asking them
  directly.
- Managed agent assignments now use GPT-5.6 Sol for architecture, planning, and requirements; GPT-5.6 Terra for
  code generation, operations, review, and validation.
- The VS Code projection launches Azure MCP through an APEX-local shim. The managed MCP configuration remains
  version-free while the CLI package pins the Azure MCP dependency for reproducible consumer installs.
- The APEX coordinator now handles project CRUD through native client questions and narrow MCP operations: create,
  list, resume, and confirmation-required deletion.
- New APEX projects now start with the local target by default; target scope is deferred to later workflow stages.
- Requirements intake now presents curated Azure service, security, authentication, compliance, region, and operations
  recommendations as native single-select or multi-select controls where the kernel provides options.
- Retired repository-source instruction files now map through a complete ledger into managed `apex-*` consumer
  instructions packaged for both supported client projections.

### Re-baselined

- Added unqualified, no-I/O design capability placeholders for documentation research, RBAC catalog, compute-region
  evidence, and Entra application intent. They return a stable unavailable result until lifecycle qualification exists.
- Added a candidate-bound client measurement preflight that fails closed on client availability, selected-version,
  Copilot Chat extension, worktree, and gate-command-scope drift without installing or interacting with clients.
- Refined managed Azure defaults, ADR, RBAC, and Microsoft Docs guidance to block on unavailable evidence and avoid
  unsupported task-context, contract, or rendering claims.
- Added evidence-scoped operational checklists for governance, compliance,
  capacity, inventory, diagnostics, Kusto, cost, validation, and deployment.
  The deployment checklist preserves circuit-breaker and governance-drift
  routing while retaining trusted provider execution boundaries.
- Added test-only unavailable operational capability placeholders for governance
  discovery, inventory, capacity, diagnostics/Kusto, compliance, and cost.
- Added a source-hashed, deferred Azure Functions recipe-pack manifest and managed preparation, migration, Terraform
  pattern, test, and import guidance. Materialization, cloud reads, apply-mode tests, publishing, and cutover remain
  unavailable pending authorized capabilities.
- Refined the internal native workflow, requirements, architecture, planning, CodeGen, and operations skills to match
  current kernel and MCP behavior, including typed intake, task ownership, evidence, binding, and taskless-operation
  boundaries. No capabilities, workflow grants, deployment behavior, or live provider integration changed.
- Completed the managed Azure ADR, Azure Defaults, Azure RBAC, and Microsoft Docs guidance migration ledger entries.
  Safe decision knowledge is packaged in consumer references; direct operations and mutable discovery remain excluded
  or capability-deferred.
- Added a matrix-derived skill catalog review and deterministic intent fixture that retain explicit gaps until lifecycle,
  live-provider, and paired-client evidence is available; this does not close issue #219.
- Restored managed Azure Compute, Storage, and Entra identity decision guidance with source-reviewed family, VMSS,
  price-evidence, storage authentication and lifecycle, OAuth, permission, and diagnostic rules. Direct SDK, CLI,
  IaC, credential, data, consent, and cloud operations remain outside the consumer skills.
- Completed the managed artifact, deployment, cost, governance, and Mermaid guidance parity ledger entries. Adapted
  guidance remains bounded to accepted evidence and trusted lifecycles; unqualified producers, renderers, discovery
  packs, live pricing, direct commands, recipes, SDK examples, and CI definitions remain unavailable.
- Completed managed assessment guidance parity for cloud migration, compliance, Kusto, quotas, resources, and
  preflight validation. Source-derived readiness and evidence interpretation are packaged for both clients; provider
  queries, discovery, SDK actions, remediation, code conversion, and command execution remain explicitly deferred.
- Added the managed `apex-azure-defaults` consumer skill with role-scoped guidance for projected governance, security,
  naming, tagging, and AVM/module decisions without direct Azure operations.
- Added managed `apex-azure-adr` and `apex-azure-rbac` consumer skills with role-scoped decision-record and
  least-privilege assignment guidance for projected architecture workflows.
- Added managed consumer guidance for Azure design, validation, operations, identity, migration, Terraform, inline
  diagrams, and derived artifact presentations, with direct cloud actions retained behind kernel-controlled capabilities.
- Deepened managed Bicep guidance with source-reviewed module interfaces, environment input rules, private endpoint and
  DNS composition, compiler/provider gotchas, and a CodeGen acceptance checklist.
- Completed managed Terraform guidance parity with receipt-gated plan and state-boundary assessment, test mock and
  plan-mode design, and import mapping and adoption attestation; operational Terraform actions remain capability-owned.

- Fixed clean devcontainer creation by normalizing named-volume ownership before cache use and removing generated
  Python package metadata after the local apex-recall install.
- Rebuilt documentation as a vNext-only Diátaxis set, generated CLI and MCP inventories from source, simplified active
  project controls, and archived superseded guides and candidate narratives with provenance and reintroduction guards.
- Audited repository-root files, restored Gitleaks default secret detection, retired zero-consumer root configuration,
  and removed stale original-APEX metadata, exclusions, and release automation claims.
- Reviewed every direct npm dependency and selected the newest releases available through the required package feed,
  removed unused `jsdom` and redundant overrides, corrected workspace ownership, patched vulnerable transitives, and
  replaced deprecated `whatwg-encoding` with maintained `encoding-sniffer` backed by `@exodus/bytes`.
- Reduced the development container to the vNext toolchain, removed Deno and original APEX authoring utilities,
  synchronized the exact VS Code extension inventory, and enforced portable named volumes plus Linux `amd64`/`arm64`
  support through repository validation.
- Removed redundant and zero-consumer root npm scripts, merged overlapping live-validator tests, centralized shared
  Node validation in `validate:_node-core`, and archived completed benchmark/dead-test utilities with provenance.
- Consolidated shared GitHub Actions setup, removed no-op maintenance inputs and duplicate Markdown/IaC steps, and
  archived the devcontainer CI workflow already disabled by DECISION-009.
- Consolidated duplicate lint aliases onto canonical validators, replaced repeated vNext CI steps with
  `qualify:vnext`, and removed obsolete hook paths and the unused model-catalog index writer.
- Archived the broken original-APEX E2E workflow, benchmark scripts, prompts, and fixtures after vNext deterministic,
  package, and exact-head qualification became authoritative.
- Linked previously unreachable skill references from their parent indexes and tightened repetitive discovery
  descriptions without changing capability behavior or routing boundaries.
- Fixed Requirements input and authoring so blank or inferred sentinel answers are rejected, kernel questions identify
  the decision areas to cover, and MCP task context returns recorded answers plus stageable output templates without
  requiring filesystem access.
- Fixed Requirements task sequencing so agents handle `needs_input` before requesting task context and use only the
  exact task ID returned by a subsequent `nextTask` result.
- Removed unreferenced archived skill copies from `.archive/_archived_skills`; Git history remains the provenance source,
  while contract-bound legacy agent and retired automation archives remain tracked.
- Removed the retired custom Azure Pricing MCP source, tests, package metadata, and dependency-update surface after
  direct Microsoft ARM MCP access and pricing parity validators became authoritative.
- Replaced exact live VS Code, Copilot Chat, and GitHub Copilot CLI pins with a rolling latest-stable policy. Live
  outcomes bind observed versions and executable hashes per candidate; historical context fixtures remain immutable.
- Removed duplicate validator, test, packaging, Terraform, and Python setup from pull-request release qualification.
  Required CI remains authoritative for those checks; exact-head qualification now runs only the release scorecard and
  compact evidence bundle.

- Replaced the custom Azure Pricing MCP with direct Microsoft Azure Resource Manager MCP access in VS Code and Copilot
  CLI. Every managed agent receives explicit read-only Cost Management and Pricing tools; custom transport, runtime-pack,
  CI, hook, Dependabot, and dev-container maintenance paths are retired.
- Corrected the ARM MCP product boundary: Azure Resource Manager MCP is distinct from Azure MCP Server and exposes
  documented CostManagement/Pricing toolsets at `https://mcp.management.azure.com`. Removed the unrelated Azure MCP
  characterization from active pricing ownership.
- Added a format-neutral diagram semantics manifest covering all existing golden scenarios and froze routing of inline
  diagrams to Mermaid and standalone diagrams to Python. Draw.io remains transitional pending measured rendering
  parity.
- Migrated active design, planning, as-built, artifact, benchmark, and E2E diagram consumers to editable Python source
  with PNG/SVG outputs. Added a fail-closed consumer inventory; Draw.io remains available only for historical
  readability and bounded repair pending measured rendering parity.
- Added strict pricing request/evidence contracts and a canonical ARM pricing replacement parity registry covering
  typed arithmetic, meters, commitments, ambiguity, uncertainty, throttling, freshness, and content-free provenance.
  Microsoft ARM MCP is the direct pricing authority; APEX retains workflow, evidence-acceptance, and gate authority.
- Selected VS Code `1.130.0` and Copilot Chat `0.58.0` exactly from the completed content-free context receipt, with
  validator-enforced version and provenance binding. Paired live client qualification remains open.
- Added versioned, content-free normalized Copilot client outcomes, scenario-specific comparison and qualification
  contracts, strict bounded collection, proof-complete evidence closure verification, and fail-closed live release
  binding. Deterministic fixture parity never grants release authority; paired exact-candidate execution remains open.
- Added schema-backed, deterministic VS Code and Copilot CLI agent projections with pinned tool selectors, source-bound
  provenance, explicit selected-client installation, and transactional update, rollback, uninstall, and reinstall.
- Added manifest-owned managed-agent target support and explicit `target: vscode` / `target: github-copilot` projection
  rendering with fail-closed source, schema, generator, installation, and drift validation.
- Characterized hidden-worker visibility and delegation without changing projection flags. The observed Copilot CLI
  exposes no tested combination that is both unavailable for direct selection and explicitly `task`-callable; exact
  paired-client qualification remains blocked pending the architecture decision in issue #180.
- Selected a fail-closed Copilot CLI worker boundary: autonomous workers are generated only for VS Code, unsupported
  role/client pairs are omitted deterministically, and parent delegation tools require a supported destination.
- Added bounded runtime evidence export for guided client qualification, deriving source-bound facts from verified APEX
  journals and immutable approval objects without creating client assertions or qualified outcomes.
- Added exact Copilot CLI surface binding for guided qualification, with binary/version checks, managed-projection drift
  detection, bounded MCP server-name inventory, and explicit unavailable results for non-selected binaries.
- Added exact VS Code surface binding for guided qualification, with host/Copilot Chat version checks, managed-projection
  drift detection, bounded extension inventory parsing, and no UI or model invocation.
- Added deterministic guided qualification checkpoints that re-run source adapters, bind canonical adapter digests, and
  expose blocked or pending interactive steps without accepting assertions or qualifying client parity.
- Added strict checkpoint resume verification that re-runs all source adapters and rejects tampered, stale, or mixed
  candidates while preserving the original checkpoint ID and interaction state.
- Added deterministic dual-client customization lifecycle evidence for init, update, rollback, uninstall, reinstall,
  unrelated-file preservation, automatic cleanup, and checkpoint integration for CLIENT-009.
- Added fail-closed paired client workspace preparation with exact candidate binding, selected projection lock
  verification, durable run identities, and cleanup after partial initialization failure.
- Added receipt-authorized cleanup for prepared client workspaces with exact marker, selection, projection, inode, and
  post-rename verification; changed or unrelated data is preserved rather than recursively deleted.
- Added content-free client input journal evidence for real pending and recorded requirements interactions, with exact
  selected-workspace, request supersession, owner epoch, and request-to-answer event binding.
- Bound fresh CLI and VS Code input journal evidence into guided checkpoints and strict resume while keeping the
  user-owned client interaction steps pending.
- Added content-free restart evidence that compares persisted run state across distinct APEX service instances for both
  selected client workspaces without claiming client-process or UI-session restart.
- Bound fresh paired restart evidence into guided checkpoints and strict resume while retaining the user-owned client
  restart interaction as pending.
- Added content-free writer-transfer evidence for pending and accepted kernel state, with immutable claim, run
  transaction, ownership, and owner-epoch verification and no cross-client interaction claim.
- Bound fresh CLI and VS Code writer-transfer evidence into guided checkpoints and strict resume while keeping the
  user-owned transfer and stale-writer interactions pending.
- Added an atomic live client-closure composer that generates canonical paired comparisons and a verified parity-only
  aggregate from the complete set of collector outcomes without claiming runtime-payload or release closure.
- Fixed client-closure payload serialization so the emitted qualification uses the exact canonical bytes required by
  evidence-manifest client qualification binding.
- Added atomic client evidence binding that combines a verified parity closure with exact candidate-bound immutable
  runtime payloads only after the existing live evidence validator accepts the complete manifest.
- Fixed runtime source-payload verification to restore the independently bound journal head before replay, allowing the
  canonical head-free source projection to satisfy complete live evidence closure.
- Added exact client-qualification candidate receipt generation with clean-worktree, repository, branch, commit,
  release-manifest, runtime-bundle, package-lock, and customization-bundle binding.
- Added versioned kernel-owned input requests and typed APEX MCP answer recording bound to the exact journal head and
  writer epoch, with deterministic option validation, replay denial, transfer reissue, and no chat-history dependency.
- Retired Terraform MCP after migrating active consumers to bounded Registry/native/documentation owners; removed its
  discovery, setup, Go feature, and health checks; archived provenance-bound evidence; and added negative regression gates.
- Added bounded native Terraform provider schema inspection and version-pinned official documentation routing with exact
  shell-free commands, deterministic statuses, execution limits, and no initialization or lifecycle authority.
- Added a bounded, fixed-origin Terraform Registry client with deterministic fixtures, pagination/cache/transport limits,
  explicit missing/unavailable results, and no Terraform lifecycle or arbitrary-URL surface.
- Characterized the former Terraform MCP registry-only tools, consumers, schema hashes, provenance gap, lifecycle
  denials, and deterministic replacement owners before retirement.
- Removed Astro MCP from active workspace discovery and added mutation coverage that rejects its legacy key and endpoint
  without changing GitHub, Azure Pricing, or Draw.io MCP behavior.
- Captured the version-bound 12-cell VS Code and Copilot CLI context baseline with unique exact-byte sources, complete
  required counter coverage, and explicit report-only dispositions for unavailable cache counters.
- Added a version-bound, machine-readable two-client context matrix and deterministic coverage reporting across
  simple-neutral, standard-Bicep, standard-Terraform, normal, and retry sampling cells.
- Added a strict VS Code local OTel JSONL adapter for exact, content-disabled token measurements without double-counting
  repeated turn summaries; cache metrics remain unavailable when the exporter omits them.
- Added a strict Copilot CLI `1.0.73` JSONL telemetry adapter that emits only allowlisted aggregate token counters;
  local content-disabled characterization and the representative two-client matrix now pass.
- Added a privacy-safe, fixture-qualified two-client context/cache sample contract and deterministic aggregation for
  Milestone O; the version-bound live matrix above now supplies representative baseline evidence.
- Closed Milestone N with isolated documentation, JavaScript, workflow, and artifact pre-commit parity measurements,
  preserving serial Git-index ownership and deferring dynamic context sampling to Milestone O.
- Standardized text and JSON diagnostics for registry and hosted-workflow contract validators while preserving their
  validation rules and failure exits.
- Derived runtime and compact artifact heading metadata from canonical templates with explicit non-template exceptions,
  byte-parity validation, and mutation coverage.
- Reduced pre-commit Git-index writers to the two genuine generators and delegated Terraform formatting to its canonical
  npm command while retaining exact Python scope, serial execution, and fail-closed behavior.
- Added deterministic VS Code and Copilot CLI workspace projections from one managed customization manifest, with
  explicit MCP discovery files, per-client content digests, and one transactional npm lifecycle.
- Archived the obsolete upstream workflow synchronization command with provenance and rollback guidance; standalone
  workflow files and hosted contracts remain authoritative.
- Reopened every `0.10.0` release gate for the expanded product contract. No
  exact release candidate is currently selected.
- Added GitHub Copilot CLI as a first-class target beside GitHub Copilot in VS
  Code, with release acceptance based on equivalent typed workflow outcomes.
- Selected typed, read-allowlisted Azure Resource Manager MCP adapters to
  replace custom managed pricing after measured parity, while native Terraform
  CLI remains the lifecycle authority.
- Selected retirement of active Astro, Terraform, custom pricing, and Draw.io
  MCP dependencies only after their individual replacement gates pass.
- Selected Mermaid for new inline diagrams, Python for new standalone diagram
  artifacts, structured bounded-improvement outcome measurement, and npm-only
  generation of both client projections.
- Demoted prior exact-main, package, security, VS Code, and live Azure evidence
  to historical characterization pending complete requalification.

### Added (APEX vNext Phase 0A baseline)

- feat(vnext): add guarded `--replace-existing` live qualification preparation that requires Gate 4 closed and no active
  writer ownership, backs up the prior `.apex` tree, and restores it after any failed task or validator.
- feat(vnext): added durable project controls, structured work-item and regression intake, and an offline validator for
  requirement references, local links, issue-form fields, and frozen Phase 0A evidence.
- docs(vnext): added approved v1 baseline decisions, candidate transcripts and manifest, the
  preserve/change/retire compatibility matrix, deterministic golden scenarios,
  the known-defects ledger, and the v1 maintenance policy. The baseline tag
  remains blocked pending a clean-commit evidence rerun.
- feat(scripts): added `validate:v1-compatibility-matrix`, which compares the
  Phase 0A matrix with live agent definitions, schemas, workflow nodes, MCP
  servers, and `apex-recall` commands.
- fix(scripts): bound Azure Pricing MCP tests to the component virtual
  environment, installed its development extras, declared the root Python test
  runner, and installed the independently locked documentation-site toolchain
  during devcontainer setup. CI now creates the same component environment and
  selects each matrix image in the job's ephemeral canonical devcontainer config,
  preserving local-feature resolution within the required workspace trust boundary.
  The v1 compatibility validator now invokes the repository-owned `apex-recall`
  module instead of requiring a globally installed console script.
- docs(vnext): initially narrowed the first-release Copilot client scope to VS
  Code and deferred GitHub Copilot CLI support. This historical decision is
  superseded by the two-client re-baseline above.
- docs(vnext): revised the rewrite plan around workspace-native customizations,
  direct interactive handoffs, model-tier-safe subagents, a durable walking
  skeleton, contract waves, an early dual-track proof, lazy capability packs,
  cached validation, inherited promotion gates, bounded evidence, writer
  transfer, and secure Terraform CI plan transport.
- feat(vnext): implemented the TypeScript contracts, kernel, authorized
  capabilities, deterministic renderers, CLI/MCP control plane, testkit,
  managed VS Code customizations, runtime configuration, native IaC generation
  and provider adapters, capability-pack management, schema export, validation,
  reproducible package/SBOM/provenance tooling, deterministic qualification,
  CI lanes, and versioned preview documentation. Live VS Code agent behavior,
  Azure deployment-stack behavior, production Terraform CI plan transport, and
  final release scorecard evidence remain explicit pre-cutover gates.
- feat(vnext): added a strict live-qualification evidence contract and deterministic
  `live:vnext` template, validation, and rendering commands that bind manual VS Code,
  GitHub, and Azure results to exact candidate and evidence hashes without executing
  approvals or cloud operations.
- feat(vnext): collect release scorecard evidence from 100 real contract mutations, capability fault cases, and cache-key
  mutations, plus replayed gate revisions and serialized `taskContext()` projections from each dual-track run.
- feat(vnext): automate clean exact-head validation, package qualification, release scorecard sampling, workspace
  compaction, artifact hashing, and fail-closed receipt generation locally and in GitHub Actions. The automation has no
  merge, cloud dispatch, publication, tagging, or cutover authority.
- feat(vnext): added a generic authenticated AES-256-GCM envelope and deterministic repository-state transfer commands
  with a selected-run allowlist, recursive content-addressed object closure, secret and size checks, atomic mode-`0600`
  import, idempotent retry, claim-bounded expiry, and separate writer-transfer acceptance. Production CI remains blocked
  pending live proof.
- feat(vnext): added recipient-bound exact provider-authority transfer commands that export only the selected preview
  binding and its referenced encrypted Terraform plan, validate all authority and file cross-links before restrictive
  atomic import, and exclude local keys, latest pointers, unrelated runtime files, and plaintext plans. Production CI
  remains blocked pending live separate-job proof.
- feat(vnext): added truthful GitHub Environment Gate 4 approval evidence derived only from strict GitHub Actions
  context, bound to the accepted writer-transfer owner, repository, branch, commit, workflow, run, job, and canonical
  recipient. The protected environment is bound through the encrypted state handoff and accepted ownership. Approval
  expiry is bounded by the exact preview. Evidence identifies the workflow actor rather than an environment reviewer,
  and production CI remains blocked pending live protected-environment proof.
- feat(vnext): support one exact post-preview writer transfer by separating semantic dependency revision from writer
  authority, authenticating claim creation against the current lease, persisting one-hop ownership lineage, and binding
  Gate 4 and provider authorization to the exact transfer claim. Terraform preview can encrypt a saved plan for an
  explicit execution recipient. Active leases, lease-bounded approval expiry, and journal compare-and-swap prevent
  pending or racing transfers from retaining authority. Production workflows remain blocked pending live proof.
- fix(vnext): make first Bicep deployment-stack preview non-mutating by listing stacks in the target resource group and
  selecting the exact configured name in process. A missing stack binds an empty managed set; malformed, duplicate, or
  wrong-scope list entries fail closed before Gate 4.
- feat(vnext): allow a newly validated deployment preview to reopen Gate 4 on the same run, preserving prior evidence
  while requiring a fresh exact approval. This supports expired-preview refresh and sequential apply/destroy without
  promotion.
- feat(vnext): add a bounded live-qualification preparation command that derives strict artifacts from the exact
  repository candidate, records native availability and validation evidence, and stops before preview with Gate 4 closed.
- feat(vnext): prepare the manual exact-head Bicep/Terraform live qualification workflow, default-deny encrypted handoff
  storage, local dispatch/retrieval launcher, and structural mutation validator. The workflow separates preview and
  Environment-approved apply authority, uses refreshed OIDC tokens, binds exact governance inputs, returns authority to
  the initiating handoff, and requires a reviewed default-branch workflow bootstrap. Backend public network access is
  Disabled at rest; each bounded session applies the policy exclusion only for that session, adds one runner `/32`, and
  verifies unconditional restoration to Disabled with the exclusion removed. It does not claim live proof until the
  user-owned GitHub and Azure ceremonies run.

### Fixed (APEX vNext security)

- fix(deps): pin the development-only `xmlbuilder2` parser to `js-yaml` 4.3.0, removing the high-severity merge-key
  quadratic-complexity denial-of-service advisory from release tooling.
- fix(vnext): validate Azure resource-group and storage-account names at the live handoff argument boundary before
  generating Terraform backend HCL, rejecting quote, newline, and Azure-invalid injection payloads.
- fix(vnext): derive release SBOMs from `package-lock.json` instead of the ambient `node_modules` tree so package
  qualification remains deterministic when the developer installation contains unrelated or invalid dependencies.
- fix(vnext): allow a fresh preview after terminal writer-transfer recovery to carry only repository-backed
  `.apex/**` authority drift while continuing to reject source changes and renames.
- fix(vnext): replace the unenforceable single-runner IP handoff exception with a reviewed, time-boxed Entra-only public
  endpoint session that retains RBAC and encryption and verifies restoration to firewall `Deny` plus network `Disabled`.
- fix(vnext): parse both canonical two-column Git porcelain and the command wrapper's first-line trimmed form when
  enforcing dispatch-only `.apex/**` drift, without permitting source changes or renames.
- fix(vnext): request Azure what-if with `--no-pretty-print` so the native Bicep provider receives strict JSON instead
  of the human diff formatter; stderr warnings remain separate and exact-preview normalization stays fail-closed.
- fix(vnext): allow dispatch to carry only repository-backed `.apex/**` preview and approval drift while retaining exact
  `main` binding and rejecting every source, workflow, rename, or non-APEX workspace change.
- fix(vnext): exclude reproducible capability source packs from repository-backed `.apex` state, matching the existing
  encrypted state-transfer allowlist while retaining locked runtime manifests and authoritative journal state.
- fix(vnext): make local APEX Gate 4 the sole deployment approval and bind it to the intended CI recipient before one
  encrypted writer/provider handoff. The unprotected GitHub Environment scopes OIDC and configuration only; CI can no
  longer create previews or approvals.
- fix(vnext): bind live qualification launch, dispatch, and release evidence to `jonathan-vella/apex-vnext`. Copied
  workflows and manifests from another repository now fail closed before cloud mutation.
- fix(vnext): replaced polynomial storage-security regular expressions over generated Bicep and Terraform source with
  a bounded line-oriented assignment scan. Adversarial dual-track coverage protects the fix in
  [#537](https://github.com/jonathan-vella/apex/issues/537).
- fix(vnext): launch the managed MCP server through the installed workspace-local CLI instead of assuming the VS Code
  extension host exposes a bare `apex` command on `PATH`; packed clean-consumer tests now connect over stdio and call
  kernel status through the generated configuration.
- fix(vnext): allow live qualification scenarios to start and complete after their unavailable-by-default evidence
  template is created, while rejecting pre-template and inverted timestamps.
- fix(vnext): install a nested `.apex/.gitignore` that excludes local leases, work staging, saved plans, and
  recomputable caches while preserving repository-backed project journals and evidence for cross-device resume.
- fix(vnext): return a valid structured MCP acknowledgement after recording requirements input instead of emitting
  an invalid tool result after the journal mutation succeeds.
- fix(vnext): allow `live:vnext validate` to bind supplied evidence payload files to manifest hashes and byte counts,
  rejecting missing, duplicate, tampered, or incorrectly sized evidence before release qualification is accepted.
- fix(vnext): persist native preview bindings and encrypted Terraform plans across CLI processes under restrictive local
  state, bind Terraform source/variable/lock bytes, and require explicit ownership authorization for destructive Bicep
  deployment-stack cleanup.

### Changed (Model migration — Claude Sonnet 4.6 → Claude Sonnet 5)

- chore(agents): migrated all 11 agents/subagents in the Sonnet cohort
  from `Claude Sonnet 4.6` to `Claude Sonnet 5` (API model id
  `claude-sonnet-5`) — `02-Requirements`, `04-Design`,
  `06b-Bicep CodeGen`, `06t-Terraform CodeGen`, `08-As-Built`,
  `11-Context Optimizer`, and the five IaC validate/whatif/plan/precheck
  subagents (`bicep-validate-subagent`, `bicep-whatif-subagent`,
  `terraform-validate-subagent`, `terraform-plan-subagent`,
  `policy-precheck-subagent`). `Claude Sonnet 4.6` is now
  `deprecated: true` in `model-catalog.json`, retained for audit
  history only. CodeGen agents stay pinned to `effort: high` (no
  `xhigh` escalation — AVM generation is structured execution, not
  deep reasoning).
- docs(vendor-prompting): `claude-best-practices.md` gains rule
  R-CL-10 covering Sonnet 5 migration deltas (adaptive thinking on by
  default, manual extended thinking removed, new tokenizer ~30% more
  tokens, more literal instruction following, review-harness coverage
  guidance), citing the new
  [prompting-claude-sonnet-5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-sonnet-5)
  source. `rules.json`, `family-support.md`, and `SKILL.md` source
  citations updated; `fetch-vendor-prompting-guides.mjs` now tracks the
  new source for drift detection.
- docs: updated all cross-references in
  `agent-authoring.instructions.md`, `agent-operating-frame.instructions.md`,
  `context-optimization.instructions.md`, `context-management` skill
  token budgets, `workflow-engine` handoff guide, `docs-writer`
  repo-architecture reference, the docs site (`agents.md`,
  `architecture-explorer-graph.json`), and `tools/registry/agent-registry.json`.

### Removed (tools/scripts dead-code cleanup)

- chore(scripts): delete orphaned/one-time scripts with no npm, hook, or
  CI wiring — `report-agent-body-sizes.mjs` (superseded by
  `assess-agents.mjs`), `migrate-legacy-findings.mjs` (one-time v1.0
  findings migration), `bench-hooks.sh`, `crawl-dev-site.mjs`,
  `strip-handoff-kind.py`, and the eight `markdown-prettifiers/*.py`
  one-time doc-styling tools. Companion cleanup drops the
  `markdown-prettifiers/**` ignore glob from `.markdownlint-cli2.jsonc`
  and the stale migration reference in `validate-challenger-findings.mjs`.

### Added (Workflow hardening — issue #425)

- feat(skills): `azure-artifacts` SKILL.md gains a `## Post-write
  validation` table (JSON → `python -m json.tool`, Bicep →
  `bicep build --stdout`, Terraform → `terraform fmt -check` +
  `terraform validate`; Markdown delegated to the lefthook
  `artifact-validation` hook). The shared agent operating-frame
  instructions reference it so every Step 1–7 agent inherits the rule.
  Guarded by `tests/scripts/test_post_write_validation.mjs`.
- feat(scripts): `safe-shell.mjs` linter gains two new rules.
  `command-portability` flags bare `rg` / `fd` / `bat` invocations in
  committed shell snippets unless a `command -v <tool>` guard appears
  in the same fence. `agent-output-no-heredoc` flags heredoc, `tee`,
  `>`, and `>>` writes targeting `agent-output/**`. Fixture-driven
  tests in `tests/scripts/test_safe_shell.mjs` cover guarded,
  unguarded, append-redirect, tee, and indented-heredoc cases.
- feat(instructions): `no-interactive-shell.instructions.md` gains
  Rule 4 (Command portability). `no-heredoc.instructions.md` gains
  the no-shell-writes-to-`agent-output/**` sub-rule.
  `agent-authoring.instructions.md` gains rules for the new
  no-shell-writes-to-agent-output and execution-subagent invocation
  prompt contracts.
- feat(agents): canonical execution-subagent invocation prompt
  template at
  `tools/apex-prompts/utility-prompts/execution-subagent.prompt.md`
  with three required H2s (`## Objective`, `## Commands`,
  `## Expected return`). Parent agents must follow this shape when
  calling `runSubagent` for validate / what-if / plan /
  policy-precheck / cost-estimate / challenger-review subagents.
- feat(schemas): `deployment-preview-v1` JSON schema at
  `tools/schemas/deployment-preview.schema.json` defines the
  five-line deploy approval block composed by 07b/07t from
  what-if / plan / policy-precheck / cost-estimate JSON.
- feat(apex-recall): new `transition` subcommand bundles
  `complete-step` (with challenger-findings gate) + N×`decide` +
  next-step `start-step` into a single atomic
  `00-session-state.json` write. Preferred path for step changes;
  legacy commands remain. Exit 2 when the challenger sidecar is
  missing (same semantics as `complete-step`). Six tests in
  `tools/apex-recall/tests/test_transition.py`.
- feat(agents): `07b-bicep-deploy` and `07t-terraform-deploy` add a
  `## Deploy Approval Block` step that renders a five-line gate
  (creates/modifies/deletes, destructive, deploy_gate, cost_delta vs
  envelope, decision) before `azd up` / `terraform apply`. Composed
  preview is persisted to
  `agent-output/{project}/06-deploy-approval.json` conforming to
  `deployment-preview-v1`.
- feat(skills): `iac-common` gains `## Bounded retry` (3-attempt cap;
  escalates with `proceed-with-substitute` / `change-region` /
  `abort`). Referenced from 07b, 07t, 04g-governance. New
  challenger-checklist entries flag missing approval blocks and
  unbounded retry loops.

### Changed (Workflow hardening — issue #425)

- `.github/copilot-instructions.md` advertises
  `apex-recall transition` as the preferred call for step changes.

### Changed (tools/scripts validator wiring)

- chore(scripts): wire `validate-context-budget.mjs` into `validate:_node`
  and `validate:_node-ci` (new `validate:context-budget` alias) so the
  documented Per-Step File Re-Read Budget (HARD LIMIT) is enforced in CI
  instead of sitting unwired. The validator itself runs as part of
  `validate:_node` / `validate:_node-ci`. A standalone smoke test
  (`tools/tests/validate-context-budget.test.mjs`, runnable via
  `test:context-budget`) guards the alias wiring and validator health in
  local development.

### Rollback (Workflow hardening — issue #425)

The change is additive. Rollback paths:

- `apex-recall transition` — legacy `checkpoint` / `decide` /
  `complete-step` commands remain functional; orchestrators can
  revert to them.
- Deploy approval block — the H2 in 07b/07t can be reverted by a
  one-line agent edit; existing what-if + policy-precheck flow is
  preserved.
- safe-shell rules — additive; no behavior change for compliant
  snippets. Disable individual rules by removing them from `RULES`
  in `tools/scripts/safe-shell.mjs`.

### Changed (tools/scripts DRY — _lib/json)

- refactor(scripts): extract `readJson` / `readJsonSafe` / `writeJson` /
  `sha256File` into `tools/scripts/_lib/json.mjs` and adopt it across 11
  validators/generators (IaC contract + handoff + consistency, policy
  property map, environment manifest, SKU manifest + IaC coverage, SKU
  allowlist derivation, Draw.io baseline capture, Azure-icon freshness,
  explorer-graph generation). Removes the inline `JSON.parse(readFileSync)`
  duplication and the now-orphaned `fs` / `crypto` imports; behavior is
  byte-for-byte identical. Guarded by `tools/tests/lib/json.test.mjs`
  (`test:lib-json`).

### Changed (tools/scripts DRY — _lib/ajv-validator)

- refactor(scripts): extract the `new Ajv2020({ allErrors: true, strict:
  false })` + `addFormats` construction and the read-schema-then-compile
  `loadValidator` into `tools/scripts/_lib/ajv-validator.mjs`
  (`createAjv`, `loadValidator`). Adopt it across 8 validators (IaC
  contract + handoff, policy property map, environment manifest, SKU
  manifest, challenge-findings decisions, JSON-schema validator, artifact
  governance-schema check), removing the duplicated Ajv boilerplate and
  now-orphaned `ajv` / `ajv-formats` imports; behavior is identical.
  `validate-decision-keys.mjs` is intentionally left untouched (it omits
  `addFormats` by design). Guarded by
  `tools/tests/lib/ajv-validator.test.mjs` (`test:lib-ajv`).

### Changed (tools/scripts DRY — _lib/e2e-helpers)

- refactor(scripts): extract the duplicated `detectIacTool` and
  `fileExists` helpers (byte-identical across `benchmark-e2e.mjs` and
  `validate-e2e-step.mjs`) into `tools/scripts/_lib/e2e-helpers.mjs`, and
  point the e2e family's inline JSON readers at the existing
  `_lib/json.mjs` helpers (`readJsonSafe` for the null-on-error variant in
  `benchmark-e2e` + `combine-e2e-runs`; strict `readJson` in
  `measure-workflow-baseline`). `validate-e2e-step`'s JSON output contract
  is unchanged. Guarded by `tools/tests/lib/e2e-helpers.test.mjs`
  (`test:lib-e2e`).

### Changed (tools/scripts consolidation — validate-models)

- refactor(scripts): merge the three read-only model validators
  (`validate-model-catalog`, `validate-model-consistency`,
  `validate-deprecated-models`) into a single
  `tools/scripts/validate-models.mjs` with `--only=catalog|consistency|deprecated`
  (no flag runs all three). The `validate:model-catalog`,
  `validate:model-consistency`, and `validate:deprecated-models` npm
  aliases are preserved as thin pass-throughs, so hooks/CI are unchanged;
  a new `validate:models` runs the full set. Per-mode output is
  byte-for-byte identical to the former scripts (verified by diff against
  a `main` worktree). The mutating generator (`generate-model-catalog.mjs`)
  stays separate, and its `buildAssignments` helper moves into
  `_lib/model-helpers.mjs` — removing the former validator→generator
  import. All live in-repo references to the three former script paths
  (code comments, the agent-registry schema description, model-catalog.json
  metadata, vendor-prompting instructions + skill references, and the
  regenerated architecture-explorer-graph.json) are repointed to
  `validate-models.mjs`; historical CHANGELOG / QUALITY_SCORE entries are
  left intact. Guarded by `tools/tests/validate-models.test.mjs`
  (`test:models`).

### Added (docs)

- docs(concepts): add `concepts/workflow-deep-dive` — long-form
  integration view of a single APEX run covering the five context
  surfaces (skills, instructions, `.github/data/` registries,
  `apex-recall`, hooks), a per-stage sub-template walkthrough for
  Steps 1 → 7 + Post-Lessons, and the lessons-feedback loop. Ships with
  a regenerable Python-diagrams source at
  `site/src/assets/diagrams/workflow-deep-dive/gen.py` plus the
  end-to-end orchestration and lessons-loop PNGs. Sidebar entry added
  under _Concepts_ as a sibling to _How It Works_.

### Added (Plan 01 — token-reduction workstream)

- `tools/scripts/profile_debug_log.py` + `npm run profile:debug-log` —
  OTel debug-log profiler extracting token totals, per-model splits,
  askQuestions count + duration, subagent wall-time, duplicate
  file-read map, tool-payload sizes, error counts, and compliance
  warnings. Reference: `.github/skills/context-management/references/log-profiling.md`.
- `agent-output/_baselines/multi-log-baseline.json` — multi-log
  baseline (5 OTel sessions, p50/p90/max) used by Plan 01 Phase 5
  targets. `.gitignore` updated to allow this single deliverable
  through while keeping ephemeral snapshots ignored.
- `tools/scripts/validate_orchestrator_handoff.py` +
  `npm run validate:orchestrator-handoff` — Gate-boundary `/clear`
  handoff contract lint (Plan 01 Phase 2a). Hard fail when the
  verbatim resume line, the `apex-recall checkpoint` precondition, or
  the resume-path first tool call is removed or paraphrased.
- `tools/scripts/validate_review_ceiling.py` +
  `npm run validate:review-ceiling` — dual-mode validator: contract
  lint (default-depth ceiling = 2, deep-depth ceiling = 4 challenger
  passes per step) and budget mode (`--budget LOGFILE`) that counts
  per-step invocations in an OTel log.
- `tools/scripts/validate_question_batching.py` +
  `npm run validate:question-batching` — Plan 01 Phase 4 P0 directive
  plus 6-question example lint for `02-requirements.agent.md`.
- `tests/integration/smoke-run.md` — Plan 01 acceptance harness
  (manual Steps 1 → 2 with `/clear` boundaries, captures askQuestions
  count, challenger invocations, inter-`/clear` chat-span max,
  post-`/clear` first input tokens).
- `.github/ISSUE_TEMPLATE/copilot-chat-feedback.md` — upstream issue
  template for Copilot Chat behaviour outside any agent's reach
  (e.g. the parallel-retry race documented in
  `docs/devcontainer-hygiene.md`).

### Changed (Plan 01 — token-reduction workstream)

- **Gate-boundary `/clear` handoff** is now mandatory at every
  accepted Gate (1, 2, 2.5, 3, 4, 5) in `01-orchestrator.agent.md`.
  The orchestrator must run `apex-recall checkpoint` first, present
  the gate, then end the message with a verbatim resume line. The
  full contract lives in
  `.github/skills/context-management/references/compression-templates.md`.
- **Challenger-invocation ceiling**: per-step cap of 2 passes
  (`default` depth) or 4 passes (`deep` depth) with explicit
  Accept / Override / Abort `askQuestions` recovery when exceeded.
  New keys `challenger_invocations_<step>`, `challenger_override_<step>`,
  `challenger_decision_<step>` registered in
  `tools/apex-recall/docs/decision-keys.md`.
- **Filesystem precheck**: `.github/instructions/azure-artifacts.instructions.md`
  now scopes the "edit, don't `create_file`" rule explicitly to the
  three high-frequency artifacts (`sku-manifest.json`, `00-handoff.md`,
  `README.md`). General rule unchanged.
- **`.digest.md` reconciliation**: deleted the stale
  `orchestrator-handoff-guide.digest.md` reference in
  `01-orchestrator.agent.md` (digest tier was retired in
  commit `24a35809`). Decision captured in
  `/memories/repo/codegen-model-mix-2026.md`.
- **Orchestrator init**: `Starting a New Project` step 4 now
  explicitly says `create_directory` (not a `create_file`
  placeholder) for `agent-output/{project}/`.
- **02-Requirements**: P0 directive subsection at top of Phase 1
  with explicit 6-question numbered example for `askQuestions`
  batching. Target: askQuestions count ≤ 10 per Step 1.
- **Model mix swaps** (5 immediate, 1 A/B-gated):
  - 05-iac-planner: Claude Opus 4.7 → Claude Sonnet 4.6
  - 04g-governance, 07b-bicep-deploy, 07t-terraform-deploy, 10-challenger (wrapper):
    GPT-5.5 → GPT-5.3-Codex
  - 11-context-optimizer: Claude Opus 4.7 → Claude Sonnet 4.6
  - `challenger-review-subagent` (subagent): GPT-5.5 → Sonnet 4.6
    is **A/B-gated** on the `test/challenger-sonnet` branch — not
    merged. Rollback path + quality rubric in
    `/memories/repo/codegen-model-mix-2026.md`.
- **PR template**: added a "Token / latency impact" section so
  PR authors confirm whether the change moves the input-token or
  per-turn-latency budget.

### Changed (other)

- refactor(agents)!: migrate `06b-Bicep CodeGen` and `06t-Terraform CodeGen`
  from `GPT-5.5` to `Claude Sonnet 4.6`. Frontmatter `model:` flipped,
  `tools/registry/agent-registry.json` mirrored, `.github/model-catalog.json`
  regenerated (Sonnet 4.6 `use_for` adds `iac-codegen`; GPT-5.5 drops it).
  Bodies kept structurally GPT-5.5 outcome-first — only minimal change is the
  existing `## Output Contract` heading converted to an `<output_contract>`
  XML block to satisfy the Anthropic `claude-output-contract-001` rule.
  All verbatim invariants (security baseline, AVM-first contract, Phase 1.5
  HARD GATE language, `apex-recall` calls, subagent JSON consumption shape,
  Do/Don't entries) preserved byte-exact. Rationale: family alignment with the
  Sonnet validate/whatif/plan subagents these agents already dispatch, plus
  stronger verbatim invariant retention under XML-tagged contracts. Does not
  re-trigger QUALITY_SCORE 2026-05-12 (no `<context_awareness>` block added).
- feat(agents): migrate `09-Diagnose` to `GPT-5.5` and convert
  `diagnose-resource.prompt.md` to the outcome-first GPT-5.5 skeleton while
  preserving approval-first Azure diagnostics and report output.
- refactor(agents)!: simplify challenger reviews — default flow is now
  **single-pass `comprehensive`** at every mandatory step (1, 2, 4); Step 3.5
  runs `governance-reconciliation`; multi-pass rotating-lens review is
  **opt-in only** (`decisions.review_depth = "deep"` or explicit
  `10-Challenger` invocation). Tier-driven auto-fire is removed.
  **Breaking schema changes** (no alias, no deprecation window — single
  monorepo, no external consumers):
  - Rename per-step `complexity_matrix` → `opt_in_matrix` in
    `workflow-graph.json` (4 occurrences: step-2, step-4, step-5b, step-5t),
    `tools/schemas/workflow-graph.schema.json` (dropped the `required:
["simple","standard","complex"]` array under the matrix to reflect opt-in
    semantics — partial tier subsets are now allowed),
    `tools/scripts/validate-workflow-graph.mjs` (`validateChallenger()`),
    `.github/skills/workflow-engine/references/orchestrator-handoff-guide.md`,
    `orchestrator-handoff-guide.digest.md`,
    `tools/tests/subagent-file-contract.test.mjs`,
    `tools/tests/fixtures/subagent-file-contract/challenger-review.findings.json`,
    `tools/tests/bats/subagent-validation.bats`.
  - Step 4 default lens: `security-governance` → `comprehensive`.
  - New `governance-reconciliation` lens (added to `VALID_LENSES` and
    `challenger-review-subagent` `review_focus` enum).
  - New return_edges in `workflow-graph.json`: `step-4 → step-2` on
    `on_architecture_must_fix` and `step-3_5 → step-2` on
    `on_must_fix_governance_conflict` (closes gate-3 livelock when a
    finding carries `requires_step == "step-2"`; reconciliation never
    self-edits the approved architecture).
  - New challenger findings JSON shape (`schema_version: "1.0"`): adds
    `traces_to: string[]`, `suggested_fix: { artifact_path, line_range?,
proposed_edit }`, `requires_step: string`, and a `cache_inputs` block
    holding individual `artifact_sha`, `checklists_sha`, `protocol_sha`,
    `subagent_sha`, `model` plus the combined `artifact_hash`. Validated by
    new `tools/scripts/validate-challenger-findings.mjs`
    (`npm run validate:challenger-findings`).
  - Legacy `agent-output/nordic-foods/challenge-findings-*.json` (9 files)
    migrated once via `tools/scripts/migrate-legacy-findings.mjs`
    (`issues→findings`, `title→claim`, `description→evidence`,
    `failure_scenario→impact`, `suggested_mitigation→suggested_fix.proposed_edit`).
    The dangling `$schema` pointer is removed by the migration.
  - `.github/skills/azure-defaults/references/challenger-selection-rules.md`
    deleted (folded into `adversarial-review-protocol.md → ## Opt-in: Deep
adversarial review`). Inbound refs repointed in 06b/06t CodeGen agents,
    `iac-common/references/codegen-shared-workflow.md`, and the site doc.
  - New `decisions.review_depth ∈ {"default", "deep"}`, captured **once**
    per project by `01-Orchestrator` only (02-Requirements reads but never
    writes). Validated by `tools/scripts/validate-session-state.mjs`.
  - New artifact-hash findings cache: parent agents reuse prior findings
    when ALL of `artifact_sha`, `checklists_sha`, `protocol_sha`,
    `subagent_sha`, and `model` match the cached `cache_inputs`.
  - New scripts: `tools/scripts/lessons-to-checklists.mjs`
    (`npm run report:challenger-gaps`),
    `tools/scripts/challenger-telemetry.mjs`
    (`npm run challenger-telemetry`),
    `tools/scripts/validate-lens-references.mjs`
    (`npm run validate:lens-references`, wired into `validate:all`).
  - `10-Challenger` wrapper now defaults to `comprehensive`; multi-pass
    and batch mode is the explicit opt-in entry point. Retirement-review
    trigger documented (≥ 20 invocations OR 30 days post-merge).
- chore(catalog): drop the `(High reasoning)` suffix from the Opus 4.7 label.
  `Claude Opus 4.7 (High reasoning)` and `Claude Opus 4.7` were two distinct
  catalog entries pointing at the same SKU. Reasoning-effort policy is now a
  per-agent decision documented in
  `.github/instructions/agent-authoring.instructions.md` (see the
  "Reasoning-effort policy" subsection), not encoded in the model label.
  Updates: 4 agent frontmatters (Requirements, Architect, IaC Planner,
  Context Optimizer), 4 prompt frontmatters, 5 registry rows, model catalog
  (entries merged + assignments regenerated), vendor-prompting rules and
  fixtures, classify-model test, and supporting docs. Historical changelog
  entries left intact (audit-trail integrity).

### Added

- feat(agents): migrate the three remaining GPT-5.4 main agents
  (`07b-bicep-deploy`, `07t-terraform-deploy`, `08-as-built`) to `GPT-5.5`
  with outcome-first body rewrites (`Role` / `# Goal` / `# Success criteria`
  / `# Constraints` / `# Output` / `# Stop rules`). `08-as-built` gains a
  `## Subagent Budget` H2 for symmetry with the deploy agents. `GPT-5.4`
  flipped to `deprecated: true` in `.github/model-catalog.json` with zero
  remaining active assignments — the GPT-5.4 cohort is fully retired.
  `GPT-5.5` `use_for` adds `deployment-execution` and
  `as-built-documentation`. The cross-family gap between
  `as-built-from-azure.prompt.md` (GPT-5.5) and its target `08-As-Built`
  agent is closed (both same-family). The orphan
  `review-imported-iac.prompt.md` (previously GPT-5.4) is also migrated to
  `GPT-5.5`. `lint-model-alignment.mjs` gains a `gpt-5.5` classifier branch
  (pre-existing blind spot — every existing GPT-5.5 agent previously
  classified as `unknown`). `.github/skills/vendor-prompting/rules.json`
  cleaned of retired GPT-5.4 family registry entry,
  `gpt55-skeleton-001.family_overrides`, and
  `gpt-no-claude-xml-001`/`personality-scoping-001` `model_families` arrays.
  `e2e-orchestrator` (was Claude Opus 4.7 (High reasoning), now `GPT-5.5`)
  also rewritten in the GPT-5.5 outcome-first style. Catalog gains a new
  `Claude Opus 4.7` (no reasoning suffix) entry used by `09-Diagnose`.
- feat(agents): migrate the Orchestrator (was Claude Opus 4.7 (High reasoning))
  and the Sonnet 4.6 cohort (Orchestrator Fast Path, Design, Governance,
  Bicep CodeGen, Terraform CodeGen, Challenger, challenger-review-subagent)
  to `GPT-5.5`. Eight agents + one subagent receive full GPT-5.5 prompt
  rewrites following the OpenAI prompting guide skeleton (Role / Personality
  / Goal / Success / Constraints / Output / Stop), layered around the
  existing required sections (output_contract, security baseline, workflow
  contracts) which stay verbatim. Four prompt files swap accordingly
  (`01-orchestrator.prompt.md`, `resume-workflow.prompt.md`,
  `04-design.prompt.md`, `as-built-from-azure.prompt.md` — the last
  intentionally GPT-5.5 even though it invokes the GPT-5.4 08-As-Built
  agent, to keep the prompt-author UX consistent across the migrated
  cohort). Eight registry rows updated. Orchestrator self-reference body
  table corrected (high-row 'Code Gen' attribution fixed; low-row tier
  retired in favor of a footnote pointing at the registry). The six
  Opus 4.7 agents (Requirements, Architect, IaC Planner, Diagnose, Context
  Optimizer, E2E Orchestrator) and the GPT-5.4 / GPT-5.3-Codex agents and
  subagents are unchanged.
- chore(catalog): redesign `.github/model-catalog.json` as model metadata
  (`models`, hand-maintained label allow-list) plus auto-generated
  `assignments` (mirrored from frontmatter). Adds `governance` block
  documenting the source-of-truth chain. Replaces the retired `floors`
  block. Adds `GPT-5.5` (tier `balanced`) and marks `Claude Sonnet 4.6`
  `deprecated: true`.
- feat(tools): add `generate-model-catalog.mjs` (rebuilds `assignments`
  from frontmatter; `--check` mode for CI drift detection) and
  `validate-model-catalog.mjs` (enforces label allow-list, assignments
  match generator output, deprecated models absent from active
  assignments). Wired into `validate:_node` / `validate:_node-ci`. Adds a
  lefthook pre-commit hook that auto-regenerates `assignments` whenever an
  agent frontmatter file is staged.
- feat(agents): migrate Opus-tier agents from `Claude Opus 4.6` to
  `Claude Opus 4.7 (High reasoning)`. Updates 7 agent frontmatters
  (Orchestrator, Requirements, Architect, IaC Planner, Diagnose,
  Context Optimizer, E2E Orchestrator), 4 prompt frontmatters
  (`01-orchestrator.prompt.md`, `resume-workflow.prompt.md`,
  `doc-gardening.prompt.md`, `tools/tests/prompts/e2e-analyze-lessons.prompt.md`),
  the 7 corresponding rows in `tools/registry/agent-registry.json`, and the
  Orchestrator self-reference body table. The `Claude Opus 4.6` catalog entry
  is retained with `deprecated: true` for audit history. Sonnet 4.6 / Haiku 4.5
  are unchanged.
- feat(tools): replace `validate-model-floors.mjs` + the `KNOWN_MODELS`
  allow-list in `validate-agent-registry.mjs` with a single
  `validate-model-consistency.mjs` check. The agent's YAML frontmatter
  `model` field is now the single source of truth; the registry mirrors it
  and the catalog is documentation only (not enforced). Adds
  `validate:model-consistency` to `validate:_node` and `validate:_node-ci`;
  removes `lint:model-floors`.
- feat(agents): retire workspace-wide `<!-- Recommended reasoning_effort: ... -->`
  HTML annotation. Removed from 15 agent files (Orchestrator, Requirements,
  Architect, Design, Governance, IaC Planner, Bicep CodeGen, Terraform CodeGen,
  As-Built, Diagnose, Challenger, Context Optimizer, E2E Orchestrator,
  Orchestrator Fast Path, challenger-review-subagent) and from
  `agent-authoring.instructions.md`. `validate-agents.mjs` and
  `lint-model-alignment.mjs` Check 3 (reasoning_effort presence) deleted;
  remaining checks renumbered 4 → 3 (large-agent context_awareness) and
  5 → 4 (investigate_before_answering).

### Changed

- chore(audit): Phase 5 of the Opus 4.7 migration audited the 7 Opus agents
  end-to-end against Anthropic's published 4.7 behavioral changes. Strengthened
  the Orchestrator's gate-1 challenger pass language (now declared "**Mandatory:**…
  not optional and must not be skipped") and rewrote `## Resuming a Project`
  to require a 3-signal absence (no apex-recall state, no `00-handoff.md`,
  no numbered artifacts) before treating a project as new — mitigating 4.7's
  stricter literalism on empty `apex-recall show` responses. Audit table
  archived under `tmp/phase5-opus-audit-table.md`.
- docs: update `agent-authoring.instructions.md` § `model` to document the
  new source-of-truth (frontmatter canonical, registry mirrors, catalog is
  documentation), the array/string/JSON-string frontmatter form mandate, and
  the YAML-bareword forbidden form. Update `[claude-guide]:` reference link
  to the current `platform.claude.com` URL.

- refactor(hooks): consolidate agent hooks — merge `governance-audit/` and
  `session-logger/` into single `session-telemetry/` directory. Adds `tool-audit/`
  (PostToolUse metadata logging), gitleaks pre-commit guard, bats-based hook
  test suite, and CI enforcement. Lefthook pre-commit consolidated (5→2 validator
  commands, parallel enabled) and post-commit removed (checks migrated to pre-push).

- refactor(tools): consolidate tests under `tools/tests/`.
  Moves `tests/` → `tools/tests/`. Updates npm test commands,
  markdownlint excludes, and documentation references.

- refactor(tools): consolidate validation scripts under `tools/scripts/`.
  Moves `scripts/` → `tools/scripts/`. Updates 45+ npm scripts, lefthook
  hooks, CI workflows, instruction applyTo globs, and documentation.

- refactor(tools): consolidate registry files under `tools/registry/`.
  Moves `.github/agent-registry.json` and `.github/count-manifest.json`
  to `tools/registry/`. Updates path references across scripts, agents,
  skills, instructions, prompts, workflows, and documentation.

- refactor(tools): consolidate MCP servers under `tools/mcp-servers/`.
  Moves `mcp/azure-pricing-mcp/` → `tools/mcp-servers/azure-pricing/` and
  `mcp/drawio-mcp-server/` → `tools/mcp-servers/drawio/`. Updates all path
  references across config, devcontainer, agents, docs, and validation.

- feat(cli): `apex-recall` CLI v0.2.0 for progressive cross-project session recall.
  Indexes `agent-output/` into SQLite + FTS5 for low-token context recovery.
  Owns the full session lifecycle (read + write) via CLI commands; replaces the
  deleted `session-resume` skill.

- refactor(tools): consolidate JSON schemas under `tools/schemas/`.
  Moves `schemas/*.schema.json` → `tools/schemas/`. Updates all `$schema`,
  `$id`, path constants, and documentation references.

### Changed

- feat(governance): `schemas/governance-constraints.schema.json` is now
  enforced at validation time. `scripts/validate-artifacts.mjs` compiles the
  schema with AJV (draft 2020-12) and validates every
  `agent-output/*/04-governance-constraints.json` artifact in Step 5b. Drops
  the schema from advisory-only to hard-gate for the JSON companion.
- feat(governance): structured policy-override pattern — `04g-Governance` now
  emits Deny findings with an optional `override` block (`reason`, `issue_link`,
  `expiry`) instead of silently dropping overridden policies. Codegen agents
  (`06b`/`06t`) treat overrides as informational warnings and inject
  `// OVERRIDE <id> until <date> — see <issue>` banner comments above affected
  resources; missing fields or past expiry fail closed. JSON shape captured in
  new `schemas/governance-constraints.schema.json` (`schema_version:
governance-constraints-v1`) for future AJV enforcement.
- fix(agents): normalise `e2e-orchestrator.agent.md` model frontmatter to the
  standard array form `["Claude Opus 4.6"]` (was the only agent using the
  `"Claude Opus 4.6 (copilot)"` string form).
- feat(orchestrator): document the complexity auto-calc procedure in
  `01-orchestrator.agent.md` — formula read from `workflow-graph.json`
  `metadata.complexity_routing`, inputs sourced from architecture + governance
  artefacts, result persisted at `decisions.complexity` so every downstream
  agent reads the same value.
- docs: admonition taxonomy (`note`/`tip`/`caution`/`danger`) and mandatory
  `## Related` footer pattern documented in `docs.instructions.md`; footers
  added to the 6 guide pages that lacked them.
- feat(drawio): 10-point visual-quality rubric (title, footer, legend, grouping,
  spacing, palette, edge labels, canonical icons, anchor stability, cross-cutting
  container) added to `.github/skills/drawio/references/validation-checklist.md`
  with `automated?`/rationale columns. Formalise APEX palette (compute `#E7F5FF`,
  data `#FFF2CC`, security `#FFE6E6`, networking `#E6F5E6`, governance `#F5F5F5`),
  typography (title 14–16pt, service 11pt, footer 9pt), and spacing (40/80/120 px)
  in `style-reference.md`. `scripts/validate-drawio-files.mjs` adds an advisory
  palette-drift check on `03-des-*`, `04-*-diagram`, `07-ab-*`, and `showcase-*`
  files; promote to blocking with `APEX_DRAWIO_RUBRIC=strict` (default advisory
  until 0.12.0).
- perf(mcp): Azure Pricing MCP — raise HTTP pool ceiling 10→20 (per-host 5→10)
  and dedup cache TTL 30s→300s / capacity 100→512 entries, configurable via
  `AZURE_PRICING_HTTP_POOL_SIZE`, `AZURE_PRICING_HTTP_POOL_PER_HOST`,
  `AZURE_PRICING_DEDUP_TTL`, `AZURE_PRICING_DEDUP_MAX_ENTRIES`. Defaults also
  surfaced in `.vscode/mcp.json`. Cuts repeated-query latency on multi-region
  bulk estimates; retail prices refresh at most hourly so 5-min reuse is safe.
- feat(agents): add `.github/model-catalog.json` (single source of allowed Copilot
  models with vendor, tier, release date, and deprecation flag) plus
  `scripts/validate-model-floors.mjs` wired into `validate:_node` and CI. Extend
  `.github/skills/workflow-engine/templates/workflow-graph.json` with a
  deterministic `complexity_routing` formula (resource count, policy violations,
  IaC-tool weight → passes) so orchestrators auto-route challenger passes from
  session state instead of guessing.
- docs: single-source glossary — `docs/GLOSSARY.md` is now a 9-line stub pointing
  to `site/src/content/docs/reference/glossary.md` (removes 570-line duplicate,
  fixes circular `#orchestrator` self-link, moves Orchestrator to its own `## O`
  section). Clarify `VERSION.md` 0.10.0 status as pre-release/Unreleased.
- chore(instructions): narrow overly-broad `applyTo` globs on `no-heredoc`,
  `no-hardcoded-counts`, `markdown`, and `code-quality` to reclaim context budget
  on every agent load. Merge `agent-research-first.instructions.md` into
  `agent-authoring.instructions.md` (single source). Upgrade
  `scripts/validate-glob-audit.mjs` to flag any `applyTo: "**"` plus oversized
  `**/*.md` globs.
- feat(azd): per-project azd multi-project support — `azure.yaml` and `.azure/` now live
  inside `infra/{iac}/{project}/` (co-located with `infra.path: .`), replacing the
  repo-root convention that broke multi-project isolation. Environment naming uses
  `{project}-{env}` (e.g., `hub-spoke-dev`). All `.azure/plan.md` references across
  50+ files updated to project-scoped paths.
- feat(azd): add azd support to the Terraform path — 06t-terraform-codegen now generates
  `azure.yaml` (with `infra.provider: terraform`) and `main.tfvars.json` parameter mapping;
  07t-terraform-deploy gains azd detection with fallback to pure `terraform apply`.
- feat(skills): new `iac-common/references/azd-vs-deploy-guide.md` — consolidated reference
  comparing azd vs deploy.ps1 (comparison table, per-project conventions, workflow, hooks,
  azure.yaml schema, detection logic, troubleshooting). Cross-linked from azure-deploy,
  recipe-selection, and azd-deployment SDK reference.
- feat(docs): new `site/src/content/docs/guides/azd-deployment.mdx` — Astro Starlight docs
  site guide covering azd vs deploy.ps1, per-project layout, workflow, hooks, schema, and
  troubleshooting.
- feat(security): expand IaC security baseline with 6 new rules — `allowSharedKeyAccess`,
  App Service HTTP/2, MySQL SSL, Container Registry admin user (all blocking), plus
  `defaultToOAuthAuthentication` (warning). WAF pillar tagging (SE:05/06/07) and MCSB links
  added to docs site. Updated AGENTS.md security section.
- refactor(scripts): migrate 6 validators to shared Reporter pattern — validate-governance-refs,
  validate-hooks, validate-instruction-checks, validate-drawio-files, validate-excalidraw-files,
  validate-iac-security-baseline. New `_lib/regex-helpers.mjs` (`findAllMatches`) eliminates
  fragile manual `lastIndex` resets. New `_lib/glob-helpers.mjs` (`walkFiles`) provides
  consistent file-walking with symlink detection.
- fix(scripts): remove unnecessary `/g` flag from per-line `.test()` patterns in
  `check-docs-freshness.mjs` (root cause of `lastIndex` fragility).
- refactor(agents): reduce prompt-body duplication by trimming the largest deploy, architect,
  and E2E agents; extract shared deploy, codegen, placeholder-scan, and direct-execution
  protocols into reusable skill references; and raise the advisory large-agent context target
  from 300 to 350 body lines in repo guidance and validators.
- refactor(instructions): replace the monolithic IaC guidance with split Bicep, Terraform,
  and implementation-plan instruction files plus shared policy, security, and cost-monitoring
  references.
- refactor(docs): align repository docs and site docs with `.github/agents`,
  `.github/instructions`, and `.github/skills` as the single source of truth, including
  current subagent names and instruction filenames.
- feat(skills): update the `azure-deploy` skill so a missing `.azure/plan.md` automatically
  triggers the `azure-prepare` then `azure-validate` flow before deployment proceeds.
