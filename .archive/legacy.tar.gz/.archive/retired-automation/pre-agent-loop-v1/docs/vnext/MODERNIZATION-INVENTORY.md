# Modernization Ownership Inventory

This inventory freezes repository ownership surfaces before consolidation. The machine-readable source is
[`modernization-ownership.json`](../../tools/registry/modernization-ownership.json), bound to candidate
`75ac46e8e49f257d041318f9680caa14b1516fd1`. Existing registries remain canonical; this inventory references them and
does not copy their entries. New owners below are planned migration targets and do not claim implemented behavior.

## Classification Rules

- `keep`: one clear owner and adequate proof already exist.
- `consolidate`: retain behavior while replacing duplicate ownership with a generated or shared view.
- `rewrite`: the current owner is explicit, but its implementation has a proven structural limitation.
- `retire`: retain until the stated removal gate succeeds, then archive or remove.
- `investigate`: preserve the surface until consumers and replacement proof are complete.

No classification authorizes implementation by itself. Milestones I through O apply each change as an independently
revertible slice with characterization tests and baseline comparison.

The [guidance and automation review contract](GUIDANCE-AUTOMATION-REVIEW.md) defines the required Milestone H
characterization for agent guidance, Markdown, linting, and workflows. PR #94 completed those consumer maps and behavior
baselines before the related ownership entries move.

## Guidance And Invocation

| Surface                        | Class       | Canonical owner         | Decision                               |
| ------------------------------ | ----------- | ----------------------- | -------------------------------------- |
| `workspace-operating-frame`    | keep        | `AGENTS.md`             | Existing split remains authoritative   |
| `scoped-instruction-discovery` | consolidate | instruction frontmatter | `OWN-001`                              |
| `user-documentation`           | keep        | `docs/`                 | User guidance remains separate         |
| `managed-agent-manifest`       | keep        | customization manifest  | Roles, models, and invocation edges    |
| `model-catalog`                | keep        | model catalog           | Definitions plus generated assignments |
| `skill-discovery`              | consolidate | skill frontmatter       | `OWN-001`                              |
| `workflow-dag`                 | keep        | workflow graph          | Machine-readable workflow owner        |
| `managed-consumer-guidance`    | consolidate | managed instructions    | `OWN-017`                              |

## Runtime And Validation

| Surface                         | Class       | Canonical owner                   | Decision                   |
| ------------------------------- | ----------- | --------------------------------- | -------------------------- |
| `runtime-manifests`             | keep        | versioned config manifests        | Existing runtime boundary  |
| `workspace-package-boundaries`  | keep        | workspace package manifests       | Executable ownership units |
| `schema-libraries`              | investigate | contracts plus repository schemas | `OWN-005`                  |
| `customization-distribution`    | rewrite     | customization manifest            | `OWN-006`                  |
| `workflow-validator-ownership`  | keep        | kernel ownership table            | Runtime authorization map  |
| `repository-validator-graph`    | consolidate | validator graph registry          | `OWN-002`                  |
| `language-validator-boundaries` | keep        | language-native tools             | Preserve native parsing    |
| `artifact-template-validation`  | consolidate | artifact templates                | `OWN-004`                  |

## Re-Baselined Product Surfaces

| Surface                         | Class       | Planned canonical owner          | Decision  |
| ------------------------------- | ----------- | -------------------------------- | --------- |
| `copilot-client-projections`    | rewrite     | customization manifest           | `OWN-011` |
| `mcp-portfolio`                 | investigate | APEX MCP descriptor              | `OWN-012` |
| `pricing-evidence`              | rewrite     | versioned evidence contracts     | `OWN-013` |
| `diagram-routing`               | rewrite     | Mermaid and Python skills        | `OWN-014` |
| `improvement-outcome-ingestion` | rewrite     | improvement policy and contracts | `OWN-015` |
| `client-bundle-generation`      | rewrite     | CLI asset preparation            | `OWN-016` |

These rows identify migration targets only. Client projections, managed MCP access, and bundle generation remain active;
custom pricing and Draw.io toolchains are retired, while manual improvement submission remains pending modernization.

## Automation And Generation

| Surface                    | Class   | Canonical owner             | Decision                    |
| -------------------------- | ------- | --------------------------- | --------------------------- |
| `precommit-hooks`          | rewrite | `lefthook.yml`              | `OWN-003`                   |
| `github-required-checks`   | keep    | branch protection/workflows | Hosted execution boundary   |
| `maintenance-workflows`    | keep    | scheduled workflows         | Freshness and hygiene owner |
| `model-catalog-generation` | keep    | model catalog generator     | Derived assignments         |
| `entity-count-generation`  | keep    | count manifest              | Derived entity counts       |
| `avm-index-generation`     | keep    | AVM index refresher         | Generated module cache      |
| `freshness-generation`     | keep    | source freshness registry   | Drift metadata              |

## Compatibility And Diagnostics

| Surface                        | Class       | Canonical owner        | Decision  |
| ------------------------------ | ----------- | ---------------------- | --------- |
| `v1-compatibility-matrix`      | retire      | v1 behavior matrix     | `OWN-007` |
| `public-command-compatibility` | investigate | CLI command surface    | `OWN-010` |
| `validator-diagnostics`        | consolidate | shared reporter        | `OWN-008` |
| `workflow-telemetry`           | investigate | workflow baseline tool | `OWN-009` |
| `debug-log-profiling`          | investigate | local debug profiler   | `OWN-009` |

## Baseline Evidence

### Context

Static context-budget validation passes for frozen-artifact consumers. Issue #121 adds a fixture-qualified, privacy-safe
normalized sample contract and deterministic aggregation with explicit unavailable cache metrics. Issue #126 completes
the version-bound 12-cell live matrix for both supported clients with unique exact-byte sources and complete required
counter coverage. Cache-read and cache-hit counters remain unavailable for both clients, and VS Code cache-write is
unavailable under the report-only policy. Comparative context-size, token-savings, or cache-improvement claims require
remeasurement against the exact candidate using the same matrix.

### CI

Current-base `main` CI run `29838483672` passed on
`1a1de02a3a17f496c713dd3c4e425c8df8d30d0e` in 128 seconds. Earlier successful runs remain historical timing samples,
not a directly comparable post-modernization baseline. Required check names and command ownership remain in workflow
files and package scripts.

### Hooks

Hook validation and characterization tests pass. Issue #113 removes unnecessary `stage_fixed` ownership from the
read-only Markdown hook and delegates Terraform formatting to its canonical npm command. The Python hook retains its
narrower Azure Pricing scope because the repository command also validates `apex-recall`. Deterministic lock contention
coverage proves a concurrent writer fails while the Git index lock is held. Serial execution remains required because
the model-catalog and SKU-manifest generators both re-stage output through that shared index.

PR #96 repaired the characterized pre-commit Markdown failure path: the hook now invokes the repository-owned lint
command, preserves diagnostics, and propagates a nonzero result with executable regression coverage. Issue #113 keeps
that scope and failure contract while reducing index writers to the two genuine generators. Issue #119 compares three
isolated samples at `b27d173` and `75ac46e` for staged documentation, JavaScript, workflow, and artifact changes. The
base/candidate medians are 1349/1358 ms, 1759/1799 ms, 615/629 ms, and 1450/1477 ms respectively; selected hooks match,
all exits are zero, and every delta is within the 25% or 250 ms material-regression tolerance. No global parallelism
claim is made.

The `markdown-policy-enforcement` cluster records the split between audience-specific authoring guidance and the shared
executable lint contract. `OWN-018` keeps those guidance audiences separate while requiring hooks, editor integration,
and hosted checks to consume repository-owned commands with equivalent diagnostics and failure propagation.

The `exact-head-release-qualification` surface remains separate from `github-required-checks`: deterministic pull-request
checks protect integration, while exact-head qualification emits candidate-bound release evidence without merge,
publication, deployment, tag, or cutover authority.

Issue #103 adds a read-only hosted workflow contract over the existing owners. It freezes names, triggers, paths,
permissions, concurrency, action versions, external-runtime visibility, artifacts, and exact-head denial boundaries;
workflow YAML and branch protection remain authoritative and unchanged.

Issue #107 extracts the duplicated Python validation bootstrap into one digest-bound local action used by required
external tests and exact-head qualification. Required check names, workflow permissions, artifacts, commands, and
release-authority denial remain unchanged and are enforced by the hosted workflow contract.

Issue #109 retires the unconsumed upstream workflow synchronization command. Its source, hash, introduction commit,
rationale, replacement owners, and rollback steps remain under `.archive/retired-automation/`; every active workflow
file remains byte-identical and owned by this standalone repository. The `upstream-workflow-synchronization` surface
and `OWN-019` decision record this separate retirement without changing the active `maintenance-workflows` owner.

### Dependencies

The candidate lockfile SHA-256 is `5727e5fd6353b31b347cffaf6c537a5c0a6be20ce2460d66125d09b118f8b525`. Workspace
package manifests and TypeScript project references own package boundaries; exact package counts remain derived rather
than copied into this document.

### Diagnostics

Shared JSON and AJV diagnostic-library tests pass. Issue #117 migrates the modernization ownership, repository validator
graph, and hosted workflow contract family to one reporter adapter with stable text and JSON diagnostics, source paths,
summaries, and failure exits. Reporter adoption remains partial across other validator families, so output compatibility
snapshots are still required before each family migrates.

Issue #115 completes `OWN-004`: canonical artifact templates now generate both the runtime heading module and compact
JSON summary. Explicit metadata remains only for optional headings, template-only headings, and the non-template
handoff artifact. Byte-parity and mutation tests replace JavaScript source regex parsing while preserving every
existing artifact heading and validator behavior.

### Drift

Recent changes include the legacy-agent archive and managed-discovery boundary. Existing model, entity-count,
source-freshness, orphan-content, and glob-audit checks remain the drift gates. This inventory adds ownership drift
validation without replacing those specialized checks.

## Ownership Decisions

- `OWN-001`: keep skill and instruction frontmatter canonical; generate audit views.
- `OWN-002`: keep validator metadata in the schema-backed repository graph and package scripts as executable projections.
- `OWN-003`: keep only genuine generators as index writers. Representative timings pass, but serial hooks remain until
  explicit Git index coordination also passes.
- `OWN-004`: derive artifact heading metadata from canonical templates.
- `OWN-005`: defer schema-library consolidation until source and consumer provenance is mapped.
- `OWN-006`: keep npm and the customization manifest authoritative while extending the transactional client lifecycle.
- `OWN-007`: retire the active v1 matrix only after issue #13 accepts cutover; archive it afterward.
- `OWN-008`: migrate validator diagnostics to the shared reporter by characterized family.
- `OWN-009`: keep telemetry advisory until automatic, representative, privacy-safe samples exist.
- `OWN-010`: retain public compatibility aliases until consumers and replacement guidance are known.
- `OWN-011`: generate VS Code and Copilot CLI projections from one customization manifest and compare typed outcomes.
- `OWN-012`: inventory and retire MCP integrations only through per-server replacement gates and a typed descriptor.
- `OWN-013`: make versioned normalized evidence contracts authoritative for managed pricing; keep raw data restricted.
- `OWN-014`: route new inline diagrams to Mermaid and standalone diagrams to editable Python sources.
- `OWN-015`: feed only allowlisted structured outcomes into the existing inert improvement lifecycle.
- `OWN-016`: keep npm and CLI asset preparation as the only bundle-generation path, with client locks and provenance.
- `OWN-017`: consolidate shipped consumer guidance in managed instructions generated consistently for both clients.
- `OWN-019`: retire upstream workflow synchronization and preserve source only as provenance with rollback guidance.

Issue #105 converts graph-governed validation aliases into exact one-hop npm delegates while preserving every public
name, canonical implementation, argument path, diagnostic, and exit status. Fixer aliases remain unchanged because
their argument-forwarding contract is outside the validation graph.

Issue #99 owns the metadata-only first bundle slice for `OWN-006` and `OWN-016`: source-to-generated mappings,
composition provenance, per-file source metadata, and an aggregate content lock. Issue #111 adds one shared managed
source set, explicit VS Code and Copilot CLI MCP projections, per-client content digests, and shared transactional
lifecycle coverage. Issue #154 adds versioned normalized outcomes, scenario comparisons, proof-complete aggregation,
and fail-closed evidence-manifest binding. npm stays the sole package and installation authority; live client outcome
parity remains pending.

Issue #175 refreshes the managed custom-agent contract after the official `target` and environment-specific field
semantics stabilized. Shared source agents remain cross-client by intentionally omitting `target`; generated projections
must declare `target: vscode` or `target: github-copilot` and contain only client-valid fields. The slice also owns
retired-field rejection, hidden-worker invocation characterization, prompt tool-precedence checks, and paired discovery
proof without creating agent-local MCP authority or claiming Copilot cloud-agent support.

Issue #177 implements the first target-aware projection slice. Managed roles declare support for the VS Code and GitHub
Copilot environments, shared source agents intentionally omit `target`, and generated projections emit one explicit
environment target. Schema, generator, source, generated-output, installation, and mutation checks fail closed on drift;
hidden-worker invocation semantics remain a separate characterization gate.

Issue #168 freezes the `OWN-014` format-neutral semantic manifest against every existing golden scenario and makes
Mermaid/Python routing explicit. The contract records bounded reconciliations where legacy aggregate metadata conflicts
with named prompt semantics. Issue #173 migrates active workflow, template, validator, benchmark, and documentation
consumers to Python source plus PNG/SVG outputs. The original transition required measured rendering parity before
removal. On 2026-07-31, the maintainer accepted existing Python/Mermaid quality and explicitly bypassed that measurement
gate; the Draw.io toolchain is retired while frozen phase-0 evidence remains unchanged.

Issue #162 freezes the `OWN-013` pricing parity registry and strict request/evidence contracts. It binds typed money,
meter, commitment, ambiguity, uncertainty, throttling, freshness, and content-free provenance semantics. Issue #169
corrects the product boundary: Azure Resource Manager MCP is a managed HTTP server at
`https://mcp.management.azure.com`, distinct from Azure MCP Server. Issue #164 makes that service the direct pricing
authority for both supported interactive clients and retires the custom Python pricing pack without adding an adapter.

## Removal And Change Gates

Every surface has a specific gate in the machine-readable manifest. The common rule is stricter than "no references":
replacement behavior, consumers, diagnostics, required checks, and baseline impact must be proven before ownership moves
or a surface is removed. Open and deferred decisions are roadmap inputs, not permission to bundle refactors.

## Next Slice Order

Complete Milestone H characterization first. Then proceed in roadmap order through MCP retirement, client parity, ARM
pricing, diagram migration, improvement measurement, bundle and automation simplification, and active guidance rewrite.
Each slice compares its affected baseline, updates this inventory, and remains independently revertible.
