# WSL Maintenance Retirement

## Scope And Provenance

Repository maintenance authorized on 2026-09-16. The generated provenance manifest records the source commit,
original paths and SHA-256 hashes of unchanged archived bytes. Historical relative links describe the original
repository layout; archived prompts, scripts and workflows are not active instructions or execution authority.
Entries marked `superseded` preserve a previous implementation whose active path has a replacement.

## Replacement Owners

- Current product scope and delivery order: `docs/vnext/PRD.md`, `ROADMAP.md`, `DECISIONS.md` and `PROJECT.md`.
- Windows/WSL setup: `tools/scripts/setup-windows.ps1` and `tools/scripts/setup-wsl.sh`.
- Repository editor settings and extension inventory: `.vscode/settings.json` and `.vscode/extensions.json`.
- Historical optimization checks and evidence: existing optimization registries, validators and tests remain active.
- Git contributions: `.github/skills/github-operations/`; the obsolete branch-specific commit prompt is retired.
- Documentation architecture reference: canonical vNext source links replace the stale v1 inventory at its existing path.

## Research Dispositions

The review inspected the current product documents, tracked top-level inventory, package scripts, workflow registry,
editor and hook validators, documentation inventory, source references and retirement tests. Filename references were
used for candidate discovery, not as proof that a file is unused. Convention-loaded root files were checked by owner.

| Surface | Disposition and evidence |
| --- | --- |
| Container config, feature installer, lock and bootstrap | Retired; WSL setup and workspace editor checks replace them. |
| Container maintenance guide and Dependabot entry | Guide archived; updater removed; other dependency ecosystems retained. |
| Superseded build/govern prompts and optimization report | Archived unchanged; product validator reads historical input there. |
| Sensei workflow and commit prompt | Retired; remote branch absent on 2026-09-16; no protected check belongs to this workflow. |
| CODEOWNERS | Stale paths replaced with current package, customization and tooling paths; default owner unchanged. |
| Editor validators | Old versions archived; active versions validate WSL settings and retain the extension denylist. |
| Root build and lint configuration | Retained: npm, TypeScript, Ruff, Prettier, ESLint, Markdown and Vale consumers remain. |
| Root Git, hooks and security files | Retained: Git attributes/ignores, Lefthook, commitlint and gitleaks remain active. |
| Root license, contributors and provenance | Retained: attribution and source/release history are not obsolete runtime code. |
| Tools/scripts | No zero-consumer standalone scripts found; npm, CI, tests or guidance reference them. |
| Tools/registry and tools/schemas | Retained: validators, packaging, governance and fixture consumers remain. |
| Tools/apex-recall | Retained: required external Python CI check and repository recall support. |
| .github skills, instructions, data and test checklists | Retained: domain guidance, policy/AVM sources and consumer proof. |
| Other .github workflows/actions, hooks and templates | Retained: required checks, refresh, security and contributor workflows. |
| Feed setup, debug export and continuation prompts | Retained: maintainer workflows, not duplicate product authorities. |
| Config, packages, customizations and IaC fixtures | Retained: current product source, generated delivery and qualification. |
| Documentation and frozen Phase 0A | Current docs remain active; frozen evidence paths and digests remain unchanged. |
| .apex and local caches/logs/environments | Preserved; no live state, credentials or local debris copied into the archive. |

Protected contexts were verified read-only as `ci`, `External Python tests (apex-recall)` and `CodeQL`; they are unchanged.
Container update PRs #337 and #338 remained open at inspection. No PR, branch, ruleset or remote workflow was mutated.
Remaining dormant domain assets require replacement and consumer proof under roadmap Phase 4, not bulk deletion here.

## Retained Surfaces

Runtime packages, managed customizations, Azure domain skills, governance collection, live qualification harnesses,
measurement utilities, security checks, lockfiles and required CI remain active. Phase 0A is frozen in place.
Tracked `.apex` data is not retired: moving project state or customization bases needs a separate lifecycle decision.
Local caches, environments, logs and untracked files are not committed into this archive. Existing service/test edits
belonging to the parallel input-correctness work are preserved.

## Rollback

Restore a retired artifact to its original path from this directory only through a reviewed change. Restore its active
consumers, discovery, validation and documentation together. Do not execute archived automation to perform rollback.
Historical authorizations, receipts and candidate hashes never authorize a new run.

## Verification

`tools/tests/retired-automation.test.mjs` verifies archive hashes and rejects reintroduction at retired source paths.
Required product and repository validators remain authoritative; this archive does not waive checks or grant release,
deployment, GitHub branch, credential or approval authority.

Validation on 2026-09-16: product qualification, documentation validation, archive integrity, editor checks, workflow
contracts/tests, validator graph/tests, JSON/schema checks, discovery scans, hook tests, safe-shell and CI JavaScript
lint passed. The full `validate:all` command stopped at the pre-existing missing guidance-migration disposition for the
tracked `apex-unslop` root skill. That skill and the guidance registry were not changed by this cleanup; the failure is
not waived. Existing CLI service and workflow-test modifications were included in product qualification but not edited
by this maintenance run.
