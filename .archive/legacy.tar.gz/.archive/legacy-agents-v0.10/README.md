# Legacy APEX Agent Fleet

## Status

This directory preserves the pre-vNext custom agent and subagent definitions that previously lived under
`.github/agents/`. They are historical compatibility inputs and are not active VS Code customizations.

The active product experience is owned by:

- `customizations/.github/agents/` for the managed APEX coordinator, interactive specialists, and hidden workers.
- `customizations/.github/skills/` for managed workflow guidance.
- `customizations/manifest.json` for roles, models, interaction types, and invocation edges.
- `packages/` and `config/` for runtime state, authorization, workflow, and validation behavior.

## Why Archived

The legacy fleet used prompt-led step agents and dedicated deployment/review subagents. APEX vNext replaces that product
surface with a deterministic kernel, narrow MCP tools, direct interactive handoffs, and hidden bounded workers. Keeping
both fleets discoverable caused duplicate old and new APEX experiences in VS Code.

The source files retain their original hierarchy under `.archive/legacy-agents-v0.10/.github/agents/` so historical
references and the frozen v1 compatibility matrix remain auditable. Compatibility tooling may read these files, but new
features and fixes must target the managed APEX definitions and runtime.

The archive also contains the retired manual agent registry and schema, prompt-contract validators, and shared authoring
instructions that applied only to the step-agent fleet. Archived validator source is retained for audit and is not part
of the active npm validation graph.

The retired `tools/scripts/validate-v1-compatibility-matrix.mjs` has SHA-256
`fabb0f1365cef398b2e1648faeb2bf2510bb9fc2e9e148c9a85bf64b193d9c20`. Phase 0A evidence remains frozen, while current
release validation no longer reads this archive.

The retired `tools/scripts/validate-workflow-table-sync.mjs` has SHA-256
`99dfa2cf3f28a1cf4665ea043ca5b22a316dd4d8ef7189c0efd222dc59911ff7`. vNext root guidance no longer publishes the
original step-agent workflow table.

## Boundaries

- Do not add this directory to `chat.agentFilesLocations`.
- Do not invoke archived agents for current projects.
- Do not copy archived state-changing behavior into managed agents.
- Preserve these files unless the frozen Phase 0A evidence and v1 compatibility contract are retired through their
  documented release gate.
