# APEX vNext Historical Qualification Dossier

## Evidence Status

Automated, package, security-equivalent, and dual-track cloud qualification completed for historical exact `main`
candidate `25530c339410e9758ae34538427f24bddfd83e1d`. The evidence remains valid characterization of that earlier product
contract, but the commit is no longer a release candidate.

The current characterization base is `b27d17350870a0ed3d5411346701cbb2eb6a4d4b`. The `0.10.0` contract now adds
GitHub Copilot CLI parity, direct Azure Resource Manager MCP access, MCP and Draw.io retirement, bounded improvement
measurement, and npm-generated client projections. These additions reopen every affected release gate.

Maintainer decision update (2026-07-31): the measured Draw.io parity gate is explicitly bypassed for retirement.
Python standalone diagrams and Mermaid inline diagrams are accepted as sufficient replacement coverage.

No evidence in this dossier authorizes package publication, tag creation, branch changes, or production cutover.

## Reopened Qualification Gates

| Gate                          | Current disposition                                                      |
| ----------------------------- | ------------------------------------------------------------------------ |
| Exact candidate               | Not selected; current `main` is a characterization base.                 |
| Deterministic qualification   | Must repeat after all re-baseline implementation changes.                |
| VS Code qualification         | Versions selected; must run against the new bundle and exact candidate.  |
| Client parity qualification   | Deterministic harness complete; paired exact-candidate runs not started. |
| ARM MCP qualification         | Direct clients configured; paired live OAuth discovery remains pending.  |
| MCP and Draw.io retirement    | Retired from active discovery, setup, workflows, and validators.         |
| Improvement measurement       | Not implemented; prior evidence covers observe-and-propose only.         |
| Package, SBOM, and provenance | Must cover the new generated client projections on the exact candidate.  |
| Guidance and automation       | Characterized on `b27d173`; later N/O parity gates remain incomplete.    |
| Security and live Azure       | Must repeat after dependency and authority surfaces stabilize.           |

## Historical Candidate Boundary

| Role                       | Commit                                     | Meaning                                      |
| -------------------------- | ------------------------------------------ | -------------------------------------------- |
| Final exact `main`         | `25530c339410e9758ae34538427f24bddfd83e1d` | Deterministic and package evidence candidate |
| Terraform execution        | `58f9420d533a53ab11a626cb07ba6253b9eef94f` | Exact Terraform apply and destroy candidate  |
| Bicep execution            | `0edf37cc943d0090fbf4f2d5cf09ba0119c14ff1` | Exact Bicep apply and destroy candidate      |
| Last runtime-source change | `87e4c70b19c00639a19b6fe4d763e3514b96da74` | Unified release identity                     |

The unified version amendment changed package and runtime identity metadata after the cloud executions. Independent diff
review confirmed that it did not change workflows, IaC, provider behavior, Gate 4, OIDC, writer transfer, or any cloud
authority path. The prior Bicep and Terraform evidence therefore remains behaviorally equivalent, but the execution
commits remain recorded separately and are not falsely presented as the final package candidate.

## Historical Unified Version Amendment

The selected `0.10.0` amendment aligns all six workspace manifests, internal `@apex/*` dependency pins, runtime bundle,
customization manifest, CLI and MCP self-reporting, qualification metadata, package tests, and npm lock metadata.

Local checks pass:

- `npm run validate:vnext`.
- 91 CLI tests and 18 testkit tests.
- five package and clean-install tests.
- reproducible package build and all five `npm publish --dry-run --json` rehearsals.

Exact-main CI, package, and release qualification pass. The generated manifest, SBOM, and provenance bind the final
commit and match the package content qualified by CI.

## Historical Exact-Main Automation

- CI run `29827622151`: success on attempt one at final exact `main`.
- release-qualification run `29827622205`: success on attempt one at final exact `main`.
- artifact: `release-qualification-25530c339410e9758ae34538427f24bddfd83e1d`.
- GitHub artifact digest: `sha256:2983f4c0f7d58e160680f2086f1dc8c55de58c2cda8b122915e3cc38a3ef4faa`.
- `receipt.json`: 4,209 bytes,
  `sha256:89df22c99443d91b4c338df4fef2dfe74a2ddc22fad1b2cbd7d85431c77ae322`.
- `SHA256SUMS`: 796 bytes,
  `sha256:a5daa48a7e0aae6d84ae54d9a250acac8b4b08faf4c1af04ee51e78364eee5b8`.
- All nine retained artifact checksums verified successfully.
- The receipt status is `pass`; merge, cloud dispatch, package publication, tag creation, and cutover are all `false`.

| Metric                               |  Value | Samples | Decision |
| ------------------------------------ | -----: | ------: | -------- |
| Cache correctness rate               |      1 |     100 | Pass     |
| Capability failure rate              |      0 |     100 | Pass     |
| Deterministic validation escape rate |      0 |     100 | Pass     |
| First-task success rate              |      1 |      60 | Pass     |
| Gate revision loops per run p95      |      0 |      60 | Pass     |
| Restart and resume success rate      |      1 |      60 | Pass     |
| Setup completion rate                |      1 |      60 | Pass     |
| Task-context bytes p95               |  8,941 |      60 | Pass     |
| Workflow elapsed time p95            | 271 ms |      30 | Pass     |

## Historical Package And Lifecycle Evidence

The exact-main packer generated byte-bound release artifacts with Node `24.18.0`, npm `11.16.0`, and TypeScript
`7.0.2`. The package test passed reproducible double-pack, tarball inventory comparison, checksum verification, offline
clean install, CLI and MCP startup, capability install/update/rollback/uninstall, customization rollback/uninstall, SBOM,
and in-toto provenance assertions.

- release manifest: 2,314 bytes,
  `sha256:e64d6a99c4f2e2c2859d75dad684af24eef7f8aa0e5a280be08a3e35652a7be6`.
- CycloneDX SBOM: 70,873 bytes,
  `sha256:3218c9823bcd86589d7747a92ec18127441deb14f3a6b12c4cb203646efe02e3`.
- in-toto provenance: 1,434 bytes,
  `sha256:b48691c0ec9239366d110a6f555b8b7e30d48d8cbc94df6ce44b2f79f9932444`.

Each tarball checksum and byte count matched the release manifest before `npm publish --dry-run --json` passed in
dependency order:

| Package              | Version  |     Bytes | Entries | SHA-256                                                            |
| -------------------- | -------- | --------: | ------: | ------------------------------------------------------------------ |
| `@apex/contracts`    | `0.10.0` |    63,759 |      85 | `08fa44e89607a8a68446fe4fa3bf2d3ef7f5e78bf7a40ead7d768633bf21d616` |
| `@apex/kernel`       | `0.10.0` |    77,067 |     110 | `bac8a18a521130271f48a5dd70894bd5b1e226b96c716c81316dea7aea40ce2b` |
| `@apex/capabilities` | `0.10.0` |   104,877 |      94 | `0b885deddc753d5182c65d07cb4c8f92d94feac460e3ff9ff75eac885b259c71` |
| `@apex/renderers`    | `0.10.0` |    29,003 |      34 | `88c13ca9a4696ef65a220072ee74f7e9f86b3132da300856614e9c90a37eccf8` |
| `@apex/cli`          | `0.10.0` | 1,037,841 |     115 | `6fdb42fd9eaf68204668712cc0a19a7308a0b45da40db5fc4803fd0de488d9f2` |

The local dry run validates package contents and npm metadata but does not create registry provenance. Real npm
provenance requires GitHub Actions OIDC and configured npm trusted publishers. This environment has no npm identity;
the approved read-through proxy returned `404` for all five names, while direct npmjs access was blocked by the container
TLS boundary. Namespace ownership and trusted-publisher configuration therefore remain publication preconditions, not
passing evidence.

This is the first vNext package release, so no older vNext package exists for a literal registry downgrade. The supported
rehearsal covers transactional capability and managed-bundle update/rollback and clean exact-version package reinstall.
v1 state cannot be resumed in vNext. The supported procedures are in the [installation guide](../guides/installation.md).

## Historical Security Disposition

The maintainer accepted an independent review as the CodeQL equivalent while the repository was private. That review
covered the unified version amendment and found no critical, high, authorization-bypass, or release-blocking issue.
After public conversion, native CodeQL run `29830116910` passed Actions, JavaScript/TypeScript, and Python with zero open
alerts. All native CodeQL checks are required on protected `main`.

- `npm audit --package-lock-only --omit=dev`: zero vulnerabilities.
- full lockfile audit: two accepted moderate findings in the development-only Markdown lint path.
- the former parser finding remains covered by bounded name validation and adversarial dual-track mutation tests.
- no workflow, IaC, provider, or authority path changed after live qualification.
- heuristic scanning found no obvious credential in committed `.apex/` evidence.

The accepted moderate parser exposure and development lock-metadata hardening item are owned in the
[release register](REGISTER.md). Public secret scanning also reports zero open alert.

## Historical Live Cloud Evidence

All four exact previews received separate local TTY Gate 4 decisions before dispatch. Each workflow used GitHub OIDC,
immutable candidate and preview validation, recipient-bound encrypted transport, one-hop writer transfer, authority
return, and cleanup. All runs succeeded on attempt one.

| Track     | Operation |      Workflow | Preview SHA-256                                                    | Result  |
| --------- | --------- | ------------: | ------------------------------------------------------------------ | ------- |
| Bicep     | Apply     | `29816381757` | `c1782b5428b1e9dd279a687a3cef6cd141f67407cb98709208220c1dc0fd048c` | Success |
| Bicep     | Destroy   | `29817534614` | `16db4049e2e6613fc1e49ebe786d9aa483d345feb696390650b259441fc396f9` | Success |
| Terraform | Apply     | `29820944300` | `309cc8248093f1e1433e61813e82360364ad788b2b05dcaba2fb3ea858391c39` | Success |
| Terraform | Destroy   | `29821615776` | `5476841c0bebcbaf1bea4feb26a6f5aa96df763886e3da90e13c234155664bc9` | Success |

Both final journals have owner epoch 5 and 54 valid events. Both target inventories are empty. The control backend is
restored to public network `Disabled`, firewall default `Deny`, zero IP and virtual-network rules, and no temporary
exception tag. Ephemeral leases, ownership, keys, and transfer claims are intentionally absent from committed state.

## Historical Requirement Accounting

The dispositions below apply only to the product contract bound to
`25530c339410e9758ae34538427f24bddfd83e1d`. They do not close requirements added or expanded by the current PRD.

| Requirement             | Disposition             | Evidence owner                                                                    |
| ----------------------- | ----------------------- | --------------------------------------------------------------------------------- |
| `REQ-DIST-001`          | Automated pass          | Reproducible clean install and lifecycle tests; release engineering               |
| `REQ-STATE-001`         | Automated and live pass | Journal, recovery, and transfer tests plus both cloud tracks; kernel              |
| `REQ-CONTRACT-001`      | Automated pass          | Schema, metadata, serialization, and compatibility validation; contracts          |
| `REQ-WORKFLOW-001`      | Automated pass          | Manifest, gate, routing, and qualification suites; kernel                         |
| `REQ-REQUIREMENTS-001`  | Automated pass          | Typed task and requirements qualification; workflow owners                        |
| `REQ-ARCH-001`          | Automated and live pass | Cost, quota, availability, and prepared-run evidence; architecture                |
| `REQ-GOV-001`           | Automated and live pass | Policy discovery artifacts and implementation mapping; governance                 |
| `REQ-PLAN-001`          | Automated pass          | Track-neutral intent and dependency validation; planning                          |
| `REQ-IAC-001`           | Automated and live pass | Dual-track parity, validation, and exact cloud lifecycles; IaC owners             |
| `REQ-BICEP-001`         | Live pass               | Bicep apply/destroy evidence; Bicep runtime                                       |
| `REQ-TERRAFORM-001`     | Live pass               | Encrypted exact-plan apply/destroy evidence; Terraform runtime                    |
| `REQ-APPROVAL-001`      | Live pass               | Four exact local Gate 4 decisions and immutable dispatch checks; maintainer       |
| `REQ-OPS-001`           | Automated and live pass | Promotion reset, inventory, reconciliation, diagnosis, and destroy; operations    |
| `REQ-QUALITY-001`       | Automated pass          | Nine-rule exact-main scorecard and compact receipt; quality engineering           |
| `REQ-CAPABILITY-001`    | Automated pass          | Fault collectors and transactional pack lifecycle; capability owners              |
| `REQ-SECURITY-001`      | Accepted pass           | Exact-main equivalent review, audits, SBOM, and provenance; security              |
| `REQ-CUSTOMIZATION-001` | Manual pending          | Static bundle checks pass; supported VS Code behavior remains; VS Code experience |
| `REQ-GUIDANCE-001`      | Not assessed            | Historical candidate predates skill and instruction migration requirement         |
| `REQ-OPTIMIZATION-001`  | Not assessed            | Historical candidate predates the pre-agent repository optimization gate          |
| `REQ-DETERMINISM-001`   | Automated pass          | Double-pack, checksums, CI, and release qualification; release engineering        |
| `REQ-DOCS-001`          | Automated pass          | Lifecycle documentation, compatibility matrix, and docs validation; docs          |
| `REQ-IMPROVE-001`       | Automated pass          | Bounded observation, proposal, authority, retention, and injection tests; quality |

## Rollback Ownership

| Surface                       | Owner                      | Rehearsed or required response                                                                                 |
| ----------------------------- | -------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Managed customizations        | VS Code experience         | Transactional rollback; preserve locally modified files                                                        |
| Capability pack               | Capability owner           | Restore the prior verified pack or uninstall it                                                                |
| npm package release           | Release engineering        | Move the release channel to the last good immutable version; publish a fix rather than rewrite a version       |
| GitHub release or tag         | Repository maintainer      | Never move a consumed tag; mark a bad release withdrawn and issue a corrected version                          |
| Bicep or Terraform deployment | Track runtime owner        | Create a fresh exact destroy or corrective preview and require a new local Gate 4 decision                     |
| Cutover                       | Repository maintainer      | Keep the frozen v1 source and maintenance line available; redirect installs without rewriting project evidence |
| Security response             | Default `CODEOWNERS` owner | Triage, embargo, backport or forward-port, publication, and disclosure timing                                  |

## Current Requalification Gates

1. Complete Milestone H characterization and bind ownership records to the current `main` base.
2. Preserve the four-surface guidance and automation characterization, then prove each later consolidation against its
   captured behavior, diagnostics, security, context/timing, rollback, and hosted-check gates.
3. Complete paired live ARM MCP checks on exact selected clients.
4. Qualify equivalent typed outcomes and authority denials in supported VS Code and Copilot CLI versions.
5. Qualify ARM MCP OAuth discovery, direct read allowlists, excluded-tool behavior, and failure handling.
6. Prove Mermaid and Python diagram routing, bounded improvement measurement, and deterministic bundle generation.
7. Repeat package reproducibility, clean lifecycle, APEX-level SBOM, provenance, security review, and live Azure tracks
   on one new exact candidate.
8. Configure trusted publication only after a reviewed release workflow exists, then obtain separate explicit
   authorization for publication, tags, support dates, and cutover.

Until all eight gates are recorded in a new exact-candidate dossier, `0.10.0` remains unqualified for promotion.
