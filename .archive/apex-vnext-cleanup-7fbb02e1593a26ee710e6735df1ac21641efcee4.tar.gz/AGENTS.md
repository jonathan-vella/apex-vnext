# APEX

## Setup Commands

```bash
npm install                              # Install repository dependencies
npm run qualify:vnext                    # Build, test, validate, and pack vNext
```

Use the packaged `apex` CLI for consumer-project lifecycle and setup operations.

## Build & Validation

```bash
# Full validation suite
npm run validate:all

# Individual checks (most-used)
npm run lint:md                          # Markdown linting
npm run lint:json                        # JSON/JSONC validation
npm run validate:agents                  # Agent + prompt frontmatter, model alignment
npm run validate:iac-security-baseline   # TLS/HTTPS/Entra-only/no-public-blob baseline
npm run lint:safe-shell                  # No interactive shell prompts in committed snippets

# Full list (≈30 scripts) → npm run | grep -E "^  (lint|validate|test):" or
# https://apexops.pro/reference/validation-reference/

# Pre-commit/pre-push hooks (installed via lefthook on `npm run prepare`)
git push                                 # Triggers diff-based-push-check.sh automatically

# IaC validation
bicep build infra/bicep/{project}/main.bicep && bicep lint infra/bicep/{project}/main.bicep
terraform fmt -check -recursive infra/terraform/ && npm run validate:terraform
```

## Code Style

Code style (CAF naming, required tags, default region, AVM-first, unique
suffix pattern) is documented in
[.github/skills/azure-defaults/SKILL.md](.github/skills/azure-defaults/SKILL.md).
Agents read that file as part of their mandatory skill load; this file
no longer duplicates the tables.

## Security Baseline

The non-negotiable security baseline (TLS 1.2 minimum, HTTPS-only, no public
blob, no shared key, Managed Identity, Entra-only SQL, App Service HTTP/2,
Container Registry admin disabled, MySQL/PostgreSQL SSL, no public network
access for prod data services, no hardcoded secrets) is documented in
[.github/instructions/references/iac-policy-compliance.md](.github/instructions/references/iac-policy-compliance.md).
This is the source of truth for `validate:iac-security-baseline`. Typed governance
inputs may add subscription-level Azure Policy requirements.

## vNext Architecture

There is no backward-compatibility requirement anywhere in this project. Remove obsolete implementations, formats,
aliases, fallback paths, and migration code rather than preserving them for legacy consumers. Update tests and guidance
to the current contracts; keep rejection tests where obsolete input could bypass validation. Retired archives are not
runtime dependencies or compatibility requirements. Preserve audit evidence and current authorization, freshness,
ownership, and approval safeguards; their age does not make them obsolete.

- `packages/kernel/` owns deterministic state, gates, authorization, evidence, and improvement decisions.
- `packages/contracts/` owns versioned JSON schemas and contract validation.
- `packages/capabilities/` owns bounded provider and workflow capabilities.
- `packages/renderers/` owns client-neutral rendering.
- `packages/cli/` owns install, update, setup, lifecycle, and terminal interaction.
- `customizations/` owns managed VS Code and Copilot CLI projections.
- `config/*.v1.json` owns shipped workflow, policy, toolchain, and runtime defaults.

State-changing behavior belongs behind kernel authorization and typed contracts. Custom agents and skills guide users;
they do not become an independent workflow authority. Preserve stable error codes, fail closed on stale evidence, and
keep client-specific behavior at adapter boundaries.

Choose validation by the changed behavior, not by habit:

- Prose-only edits: lint the changed files and verify changed links; run project-control checks only when affected.
- Skill/instruction edits: validate affected metadata, references, invocation and discovery contracts.
- Local code edits: run the owning package build and focused regression tests immediately; expand only for concrete risk.
- Shared runtime, contract, packaging or broad maintenance changes: run `npm run qualify:vnext` once at the integration
  checkpoint after focused checks pass. Do not repeat it after each small edit within the same slice.
- Keep required hooks and CI checks enabled. Full repository validation belongs at integration/release boundaries or
  when a cross-cutting change needs it, not every wording correction.

Live cloud qualification is a separate, explicitly authorized operation and must not run as part of ordinary validation.

## Conventions Detail

For deeper guidance, agents read these on demand:

- Bicep conventions: `infra/bicep/AGENTS.md`
- Terraform conventions: `infra/terraform/AGENTS.md`
- Consumer azd co-location guidance: `customizations/.github/instructions/apex-azure-yaml.instructions.md`
- Terminal hygiene: avoid interactive `mv`/`rm`/`read` prompts and keep command output bounded; `lint:safe-shell`
  enforces committed consumer guidance.
- Azure defaults: `.github/skills/azure-defaults/SKILL.md`
- vNext product contracts: `packages/contracts/schemas/`
- Managed customization manifest: `customizations/manifest.json`
- Full validation reference: <https://apexops.pro/reference/validation-reference/>
