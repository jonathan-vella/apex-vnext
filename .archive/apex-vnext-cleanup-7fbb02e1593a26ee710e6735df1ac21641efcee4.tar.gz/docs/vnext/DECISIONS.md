# APEX vNext Decision Register

Stable IDs remain available for requirements, risks, ADRs, and issue references. Consequential architecture records
live in [ADRs](adrs/README.md).

## DECISION-001: Use Hybrid Project Governance

GitHub Issues own actionable work; repository controls own durable requirements, decisions, risks, and release procedures.

## DECISION-002: Use Main As The vNext Integration Branch

All feature work targets this repository's protected `main` through pull requests. Superseded branch history is not an
active product control.

## DECISION-003: Modernize Through Dependency-Complete Vertical Slices

Each slice includes implementation, tests, documentation, ownership migration, and rollback or retirement evidence.

## DECISION-004: Keep Improvement Observe-And-Propose Only

Improvement observations may produce inert proposals. They cannot mutate code, policy, prompts, issues, releases, or
infrastructure autonomously. See [ADR-0004](adrs/03-des-adr-0004-use-bounded-observe-and-propose-improvement.md).

## DECISION-005: Support Managed Copilot Clients Through Projections

Superseded by DECISION-012. Client-specific interaction mechanics are projections over one kernel-owned workflow.

## DECISION-006: Extend The Existing Bug Form For Regressions

vNext regressions use the repository bug form with integration head, failed check, and regression-test fields.

## DECISION-007: Treat Historical Build Plans As Nonbinding

Current requirements, roadmap, decisions, risks, source packages, and versioned configuration are authoritative.

## DECISION-008: Keep Product Documentation Self-Contained

Current source, contracts and requirements own product behavior. No historical record is required to build, test,
install or operate vNext. Supported vNext version transitions retain their explicit contract guarantees.

## DECISION-009: Do Not Run Devcontainer CI

The disabled container workflow remains archived. Repository maintenance on 2026-09-16 also retired the remaining
container setup in favor of the WSL2 setup scripts. Workspace editor and hook validation remain active. Historical
materials are optional retention only: current checks do not depend on their presence.

## DECISION-010: Keep Deployment Approval In APEX Gate 4

Gate 4 binds one exact preview, actor, target, operation, recipient, dependency revision, writer epoch, and expiry. CI
environment protection is defense in depth, not APEX approval authority. See
[ADR-0002](adrs/03-des-adr-0002-use-local-gate-4-before-ci-handoff.md).

## DECISION-011: Use A Bounded Entra-Only Handoff Session

Cross-boundary state and provider handoff uses short-lived recipient-bound evidence without shared static transport
secrets. See [ADR-0003](adrs/03-des-adr-0003-use-bounded-entra-only-handoff-session.md).

## DECISION-012: Support VS Code And GitHub Copilot CLI

Superseded by DECISION-029. Both clients receive the coordinator and interactive specialists. Their shared interactions
must produce equivalent typed outcomes; unsupported mechanics remain explicit.

## DECISION-013: Re-Baseline Every Release Candidate

Historical evidence characterizes behavior but cannot qualify a changed candidate. Required evidence is rebound to the
exact candidate before release.

## DECISION-014: Use Microsoft ARM MCP Directly For Managed Pricing

Managed clients use explicit read-only Cost Management and Pricing tools. APEX owns request/evidence acceptance,
arithmetic, workflow, and gates.

## DECISION-015: Retire Unneeded MCP And Diagram Surfaces Through Explicit Gates

A surface is removed only with consumer migration, replacement proof, archive provenance, rollback, and a negative
reintroduction check.

## DECISION-016: Keep Npm As The Sole Distribution Authority

Superseded by DECISION-033. Current implementation remains npm-owned: CLI packages, exact dependencies, release
manifest, SBOM and provenance. The permanent npm-only product restriction is superseded by DECISION-024. No distribution
migration has been selected or implemented by revising the plan.

## DECISION-017: Operationalize Bounded Improvement Without Promotion Authority

Recurring structured observations can be measured and triaged, but humans retain issue, code, policy, and release
authority.

## DECISION-018: Consolidate Automation Conservatively

Shared setup and canonical validators may remove duplication only when required check names, permissions, triggers,
diagnostics, security, and exact-head semantics remain intact.

## DECISION-019: Characterize Guidance And Automation Before Rewriting

Ownership and consumers are mapped before consolidation. Completed characterizations remain archived provenance rather
than active product instructions.

## DECISION-020: Use A Bounded Local Controller For Pre-Agent Optimization

Repository maintenance may use a separately authorized local controller with exact scope, commands, budgets, checks,
expiry, checkpoints, and stop conditions. It has no merge, release, or deployment authority.

Its availability does not require a new repository-wide optimization campaign. DECISION-025 supersedes the blanket
pre-agent product prerequisite, without bypassing executable gates or changing historical receipts.

## DECISION-021: Build A Workload Factory With Two Profiles

ALZ-backed workloads and standalone single-subscription labs/demos are both day-one requirements. Use one workflow with
explicit profile and ownership data. Outside labs, application services consume supplied networking, identity and
monitoring by default. Labs can create their workload support resources without creating an ALZ platform. Azure Policy
always wins. [PRD workload boundary](PRD.md#workload-boundary) owns the detailed scope.

## DECISION-022: Reuse Independent Archetypes And Adapt In Conversation

Import one selected COE archetype as an independent snapshot with source revision, not a continuously linked product.
Reuse existing contracts and parameters, with one authoritative owner per fact. Ask relevant change questions, confirm
consequences and manual-edit conflicts, then update affected outputs. Do not copy source deployment authority or create
a generic synchronization engine. Requirements `REQ-REUSE-001` and `REQ-CHANGE-001` own acceptance.

## DECISION-023: Preserve Rich Output Without Repeated Authoring

Use [the PRD quality reference](PRD.md#output-quality-reference) to assess useful design reasoning, visuals and
operational guidance. Reuse accepted decisions in existing renderers. Infrastructure outputs, deployment guidance and
operational readiness are mandatory; application pipelines and application-specific deployment configuration are later
optional work. Quality is not document length or a numeric score copied from a reference workload.

## DECISION-024: Use WSL2 And Decide Distribution Last

Superseded by DECISION-033. Windows via WSL2 is the initial host path; consumers do not require Docker or a
devcontainer. Keep npm usable now. Evaluate Agent Plugins together with APEX MCP redistribution only after functional
delivery, then qualify the chosen lifecycle in both clients. The choice remains open; avoid competing runtime owners,
updaters and custom frameworks.

## DECISION-025: Minimize Input Without A Token Baseline Now

Use compact task inputs, scoped guidance, relevant questions and unchanged-decision reuse. No token baseline, comparative
benchmark or new measurement framework is current work. Preserve existing safety tests and measurement utilities.
Reconcile conflicting executable gate contracts through focused tested changes before affected scenarios; no bypasses.

## DECISION-026: Use Reviewed Policy Baselines And Explicit Assumptions

Implement [issue #344](https://github.com/jonathan-vella/apex-vnext/issues/344) through deterministic subscription-only
import, existing governance reconciliation/review and Gate 2. Cover standalone subscriptions through the same contract.
The full baseline never enters model context. Quota and regional availability remain assumptions, not Architecture
evidence gates. Policy, security and deployment approval cannot be waived by an assumption or lab profile.

## DECISION-028: Require Governance Refresh At Thirty Days

Consumer clarification on 2026-09-19 fixes snapshot eligibility at less than 30 elapsed UTC days since successful Azure
collection. Refresh below that age is optional; at 30 days it is mandatory before planning or new deployment approval.
Display age and prefer reuse without repeated prompts. Observation renewal is separate from policy-content identity.
Native checks and live Azure enforcement remain required. Acceptance and implementation boundaries are owned by
[REQ-GOV-001](PRD.md#req-gov-001-governance-and-policy) and [Phase 2](ROADMAP.md#phase-2-finish-governance).

## DECISION-027: Optimize Current Inputs Before Changing Execution Mechanics

Start with the [first roadmap batch](ROADMAP.md#first-batch-input-correctness-and-scope): repair revision-safe reads,
bound task/reviewer context, correct routing and tool scope, then remove proven prompt duplication. Acceptance remains
in `REQ-OPTIMIZATION-001`; recommendation dispositions remain in the roadmap. Retain requirements-review,
architecture-review, governance-review and plan-review, equivalent client outcomes, and rich deterministic output.

Reuse confirmed requirements, decisions and pricing evidence in the existing delivery phases. This does not authorize
model downgrades, new telemetry, persistent snapshots, concurrent review commits, ID-only invalidation, asynchronous
rendering or structured-only MCP results. Those proposals require the evidence and boundaries in the roadmap before
adoption. Preserve DECISION-025, revised ADR-0006 kernel authority and scoped worker grants, journal integrity and human
approval; changing documentation
does not alter executable gates or close historical findings.

## DECISION-029: Ship One Copilot CLI Projection

Amended by DECISION-031, DECISION-032 and DECISION-033. Maintainer direction on 2026-09-23 supersedes DECISION-012.
Managed agents, skills and MCP configuration use only the Copilot CLI agent format. Supported clients are standalone
Copilot CLI and the VS Code Copilot harness, which runs CLI-format agents in the VS Code Agent Host. The VS Code Local
projection, its renderer path, `.vscode/mcp.json` and the combined installation mode retire through DECISION-015 gates:
consumer migration, replacement proof, archive provenance under `.archive/vscode-projection/`, rollback and a negative
reintroduction check. `apex init` and `apex update` reject the retired client with a stable error code and migration
guidance. The archive is never a runtime dependency. `github-copilot-cli` is the only installable projection;
`github-copilot-vscode` remains the evidence identity for VS Code running CLI agents, so paired-client comparison
continues. Builder-only VS Code tooling for this repository stays.

An `apex-next` skill replaces handoff buttons. It reads kernel status and the next task, names the owning agent, and
either delegates that agent with the prepared prompt or prints the client's selection step (`/agent` in standalone CLI,
the Agent picker in the VS Code harness) and scope prompt. Built-in CLI agents are advisory helpers only: Explore,
Rubber-duck, Code-review, Security-review, built-in Task and user-invoked Research never produce kernel evidence,
complete tasks or approve gates. General-purpose delegation, `/fleet`, `/delegate` and plan mode stay out of managed
workflows. Kernel authority, typed outcomes, the four review passes and human gates are unchanged.
[REQ-CUSTOMIZATION-001](PRD.md#req-customization-001-managed-copilot-experiences) owns acceptance and the
[CLI-only projection plan](ROADMAP.md#cli-only-projection) owns delivery.

After the slice 1 probes on 2026-09-23, the maintainer settled slices 5 to 8. The read-only context sidekick is
deferred until a Copilot CLI release launches custom sidekicks. Multi-choice input uses native `ask_user` checkboxes
where offered and numbered selection otherwise. The foreground APEX agent has read-only file tools and `task` so it
can delegate hidden workers and advisory Explore. Validator may run `bicep` and `terraform` pre-checks only through a
shell limited to those commands. The VS Code installation lifecycle tests and client-comparison tooling are
retargeted to the VS Code Copilot harness; only Local-only tests are archived. For slice 5 the maintainer retired the
rule that a subagent may not use a costlier model tier than its parent, so APEX delegates CodeGen, Reviewer
and Validator through `apex-next`. Under the maintainer's standing rule to take the recommended option while away,
slice 6 ships only Explore: the other review helpers inherit the caller's APEX completion and disposition tools, and
agent frontmatter cannot limit Validator's shell, so Validator gets none. For slice 7, checkbox answers that map
exactly to kernel options need no extra question; numbered or free-text answers still require explicit confirmation.
Slice 8 archived VS Code Local under `.archive/vscode-projection/`. Only its MCP config launched the Azure MCP shim,
and no managed agent used Azure MCP tools, so the shim and its `@azure/mcp` dependency retired with it.

## DECISION-030: Discover Governance Before Architecture

Maintainer direction on 2026-09-24 amends DECISION-026 and DECISION-027. Governance discovery runs after Gate 1 and
before Architecture, so the Architect designs against known policy. It imports the reviewed collected subscription
baseline when one exists. Otherwise it imports a shipped ALZ Corp reference baseline, generated by a maintainer script
from a pinned Azure Landing Zones Library release (root, landing zones and corp archetypes) in the collector's finding
format. Local targets always use the reference. A subscription target on the reference can pass Gate 2, as in
pre-sales without Azure access, but its reviewed subscription baseline must replace the reference before Gate 3.

The Architect owns policy reconciliation inside Architecture. Every enforcing finding (deny, modify, deployIfNotExists)
maps once to a component, property and disposition. APEX marks a finding `not-applicable` when its resource types
match no designed component; any other `not-applicable` needs a factual reason. The separate reconciliation task and
governance review retire; the Architecture review covers the policy map. After Gate 2, a subscription target still on
the reference gets a `governance-refresh` task that imports the reviewed baseline, then a `policy-refresh` task. The
kernel carries mappings whose policy definition, reference ID and effect match, marks undesigned resource types
`not-applicable` and sends only the remaining findings to the Architect. Gate 2 stays approved unless a refreshed row
is `blocked`, which reopens Architecture and Gate 2. [REQ-GOV-001](PRD.md#req-gov-001-governance-and-policy) owns
acceptance.

## DECISION-031: Replace The APEX Reviewer With Captured Rubber-Duck Reviews

Maintainer direction on 2026-10-02, design settled on 2026-10-05, amends DECISION-029. The built-in Copilot
`rubber-duck` agent replaces the managed `APEX Reviewer` for the requirements, architecture and plan reviews. A managed
`postToolUse` hook saves rubber-duck's exact output. The kernel records it in the run journal, bound to the review
prompt hash (with a request nonce) and the reviewed artifact hash, and derives the findings from it. The calling agent
adds dispositions only and cannot author or edit findings. A missing, edited, replayed or mismatched capture fails
closed. Hooks only capture; they never decide. Rubber-duck inherits the caller's tools, so a managed `preToolUse` hook
denies APEX state-changing MCP tools during rubber-duck calls; a negative test must prove that before captured output
counts as findings. Accepted risk: its model is not pinned. Slice 11 finding R9 (findings drifting across blind retries)
motivates kernel capture.

Amendment 2026-10-08 (coordinator decision on PR #421, maintainer unavailable): hooks fail open when missing or timed
out, so the kernel also refuses every operation that approves, deletes or publishes with `APEX_REVIEW_PENDING` while any
review in the workspace, or in another workspace the same MCP server serves, waits for its capture. The blocked set
extends the CP-10 MCP tool effect classification (`MCP_TOOL_REVIEW_GUARDS`). Completing the review, or cancelling its
task from the CLI after the user stops rubber-duck, lifts the guard; hooks still only capture and deny.

## DECISION-032: Use One Interactive APEX Agent

Maintainer direction on 2026-10-02 and 2026-10-05 amends DECISION-029. One user-facing `APEX` agent replaces the
coordinator, Requirements, Architect, Planner and Operator agents. Stage guidance moves into skills loaded per kernel
task. CodeGen and Validator stay hidden workers that never ask the user questions; rubber-duck replaces the Reviewer
(DECISION-031). `apex-next` stops printing scope prompts and agent switches. The APEX agent asks for all human input
in chat, including gate decisions, without forms or terminal gates. Accepted risk: an agent could claim an approval
the user did not give; the kernel records the claim with the actor and the audit log shows it. Kernel authority, typed
outcomes and the four gates are unchanged. The routing findings R1 to R3 from slice 11 are fixed in this work.

## DECISION-033: Support Native Windows Clients And Deliver APEX As An Agent Plugin

Maintainer direction on 2026-10-02 and 2026-10-05 supersedes DECISION-016 and DECISION-024 and amends DECISION-029.
It replaces the parked desktop plan. Client support matches the separate apex-jon modernization:

| Client                                | Host                   | Status                                  |
| ------------------------------------- | ---------------------- | --------------------------------------- |
| VS Code, Copilot harness (Agent Host) | Native Windows         | Supported target; qualification pending |
| GitHub Copilot app                    | Native Windows         | Supported target; qualification pending |
| GitHub Copilot CLI                    | Linux and WSL2         | Supported target; qualification pending |
| GitHub Copilot CLI                    | Native Windows         | Unsupported                             |
| VS Code Local harness                 | Any                    | Unsupported                             |
| VS Code or the app                    | macOS or Linux desktop | Best effort, not qualified              |

- **Hosts.** One host per workspace; runs do not move between a Windows client and the WSL CLI. Windows means the
  latest Windows 11 release and the one before it (25H2, 24H2), or any build where the client reports local
  sandboxing as supported.
- **Sandbox.** Client local sandboxing is a documented prerequisite that APEX assumes is on and does not check.
  Outbound network stays allowed. Because the sandbox is on, clients may use Allow All tool permissions; gate decisions
  still come from the user. Azure CLI sign-in inside the sandbox is settled during qualification.
- **Distribution.** APEX ships as one Agent Plugins 1.0 plugin: skills, the APEX agent and workers, hooks, and an MCP
  server that runs the bundled `@apexops/cli` runtime with `node`. A separate vNext marketplace repository publishes it.
  Installs and release provenance pin an immutable commit SHA; tags are release labels only. `apex init` and bootstrap
  remain the onboarding path and write a thin workspace projection: `.github/copilot/settings.json` with
  `enabledPlugins` and `extraKnownMarketplaces`, instructions with `applyTo` globs, the governance workflow and scripts,
  and `.apex/`. The plugin installs through one channel, the Copilot CLI store, which VS Code reads. `@apexops/cli`
  stays on npm for the terminal at the same exact version the plugin bundles. Node 24 LTS is the minimum. Retiring the
  copied agents and skills follows the DECISION-015 gates.
- **Models.** Agent files carry no `model`, `model-policy` or `reasoning-effort`; the user picks the session model,
  currently HydraFusion. Every state-changing MCP tool must be safe to call twice with the same input.
- **Worktrees.** Supported. Every APEX MCP tool takes an explicit workspace path, and the server resolves the shared
  `.apex/` in the main checkout through the git common directory. One writer per run applies across worktrees.

Evidence: the apex-jon Phase 0 spike passed 8 of 8 checks in all three clients on 2026-10-03 and 2026-10-04 (plugin
install, plugin agents, plugin MCP through `${PLUGIN_ROOT}`, hooks with bash and PowerShell, `ask_user`, rubber-duck
isolation and hook deny). The separate Windows probe was skipped; sandbox, Azure sign-in and worktree behavior are
proven during final qualification. The [client pivot plan](ROADMAP.md#client-pivot) owns delivery and
[REQ-HOST-001](PRD.md#req-host-001-supported-hosts-and-clients) owns acceptance.

## DECISION-034: Serve APEX MCP With The MCP TypeScript SDK v2

Maintainer direction on 2026-10-07 amends REQ-MCP-001 and follows the completed CP-22 v1 upgrade with CP-23. The
supported clients are all Copilot SDK clients: the VS Code Copilot harness, the GitHub Copilot app and Copilot CLI. They
negotiate MCP `2026-07-28` and probe stdio servers with `server/discover`. VS Code's classic Copilot Chat is not a
target.

- **SDK.** APEX MCP uses `@modelcontextprotocol/server`, with `@modelcontextprotocol/client` for tests only, both at
  exact versions. The v1 package `@modelcontextprotocol/sdk`, the `server-legacy` package and the v1-only `hono`
  dependencies are removed. Dependabot proposes upgrades, which must pass the MCP tests and the Windows job.
- **Server.** A low-level `Server` with explicit `tools/list` and `tools/call` handlers keeps APEX's own schemas,
  validation and error envelopes. `serveStdio(factory, { legacy: 'serve' })` builds the server for each stdio
  connection; the connection closes when stdin ends. A server wired with `server.connect(new StdioServerTransport())`
  answers `server/discover` with method-not-found and serves only `2025-11-25`, so APEX does not use that wiring.
- **Protocol.** APEX targets `2026-07-28`. `legacy: 'serve'` still answers a `2025-11-25` `initialize`, because Copilot
  clients fall back to it when a `server/discover` probe times out; APEX code and tests do not target that era.
- **Packaging.** The plugin ships the MCP server as one esbuild bundle with its assets, instead of a copied
  `node_modules` tree.
- **Order.** CP-09 lands first, then the SDK migration (CP-23), then the plugin package (CP-06).

Evidence: the v1 line receives only fixes until at least 2027-01-27 and implements no new protocol revisions; Copilot
CLI added `2026-07-28` support in 1.0.81, and VS Code 1.140 states the Copilot harness runs on the Copilot SDK. The
apex-jon server moved to the v2 SDK on 2026-10-04 and its `apex-plugin` build serves all three clients with a bundled
v2 `Server` over stdio, falling back to `2025-11-25` because it does not use `serveStdio`. A local probe on 2026-10-07
confirmed that only `serveStdio` answers `server/discover` and returns `2026-07-28` results. Live client evidence is
recorded in CP-20.

## DECISION-035: Deploy With azd For Labs And GitHub Actions Pipelines For Production

Maintainer direction on 2026-10-08. Production deployments run through GitHub Actions pipelines; labs deploy from a
local device with azd. Both keep the kernel's deployment authority, `REQ-APPROVAL-001` and
[ADR-0002](adrs/03-des-adr-0002-use-local-gate-4-before-ci-handoff.md): local Gate 4 is the only deployment approval.

- **Labs.** `apex deploy` gains an `azd` track alongside the Bicep and Terraform tracks. The provisioning preview is
  `azd provision --preview`; Gate 4 approves it, and `azd provision` then runs bound to that exact preview under the
  same commit, dependency revision, hash, recipient and expiry rules as the other tracks. Service deployment from
  `azure.yaml` is a separate operation: its own Gate 4 decision binds the service list and the package digests, and
  `azd deploy` runs only those packages. APEX does not run `azd up`, because no single preview covers both steps.
- **Production.** APEX generates `azure.yaml` and the GitHub Actions workflow as static, reviewable files that pass
  the normal gates, with OIDC federated credentials and no secrets in files. `azd pipeline config` creates Entra
  identities, federated credentials, role assignments and GitHub variables, so it is a separate state-changing
  operation: it runs only after its own preview and Gate 4 decision, through `apex deploy`. The workflow follows
  ADR-0002: local Gate 4 approves the exact preview and binds the CI recipient, CI accepts the one-hop transfer and
  executes only that imported preview, and the run evidence returns through `submitEvidence`. CI cannot create,
  replace or refresh Gate 4 approval. Production CI apply stays blocked until recipient-bound encrypted transport is
  qualified (`REQ-TERRAFORM-001`).
- **Agent commands.** The APEX agent never runs a command that changes Azure, Entra or GitHub settings. Read and
  diagnostic `az` and `azd` commands may run directly. Skills keep their azd and CLI guidance (CP-18), with mutations
  routed through `apex deploy` or the approved pipeline.

Today's tracks: Bicep previews with `az deployment group|sub what-if` and deploys with `az deployment group|sub create`;
Terraform previews with `terraform plan -out` and applies that saved plan. CP-26 owns delivery; CLIENT-039 and
CLIENT-040 qualify it.
