import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { buildOptimizationGateInventory, validateOptimizationGate } from "../scripts/validate-optimization-gate.mjs";

const manifest = JSON.parse(readFileSync("tools/registry/optimization-gate.v1.json", "utf8"));
const schema = JSON.parse(readFileSync("tools/registry/schemas/optimization-gate.schema.json", "utf8"));
const scripts = JSON.parse(readFileSync("package.json", "utf8")).scripts;
const trackedPaths = ["package.json", ".github/workflows/ci.yml", "packages/kernel/package.json", "docs/vnext/PRD.md"];

test("inactive optimization gate has an exhaustive non-overlapping owned scope", () => {
  assert.deepEqual(validateOptimizationGate({ manifest, schema, scripts, trackedPaths }), []);
});

function authorizedFixture() {
  const fixture = structuredClone(manifest);
  fixture.state = "authorized";
  fixture.candidate = { status: "bound", commit: "a".repeat(40), tree: "b".repeat(40) };
  fixture.authorization = {
    status: "approved",
    approver: "synthetic test actor",
    expiresAt: "2026-10-10T00:00:00Z",
    allowedPaths: ["**"],
    allowedCommands: ["npm run validate:all"],
    stopConditions: ["Synthetic fixture only; never execute a campaign."],
    budget: { maxTrackedMutations: 0, maxMinutes: 1 },
  };
  return fixture;
}

test("synthetic authorized fixture preserves structural acceptance without granting a real campaign", () => {
  assert.deepEqual(validateOptimizationGate({ manifest: authorizedFixture(), schema, scripts, trackedPaths }), []);
  assert.equal(manifest.state, "draft");
  assert.deepEqual(manifest.candidate, { status: "pending" });
  assert.deepEqual(manifest.authorization, {
    status: "pending",
    pendingReason: "Historical authorization archived; no campaign authorized.",
  });
});

test("structural validation does not require an authorized audit or captured baselines", () => {
  const draft = structuredClone(manifest);
  draft.state = "draft";
  draft.candidate = { status: "pending" };
  draft.authorization = { status: "pending", pendingReason: "No maintenance audit is authorized." };
  for (const baseline of draft.baselines) baseline.status = "pending";
  assert.deepEqual(validateOptimizationGate({ manifest: draft, schema, scripts, trackedPaths }), []);
});

test("claiming audit completion still requires captured baselines", () => {
  const incomplete = authorizedFixture();
  incomplete.state = "complete";
  incomplete.findings = [];
  for (const baseline of incomplete.baselines) baseline.status = "pending";
  assert.ok(
    validateOptimizationGate({ manifest: incomplete, schema, scripts, trackedPaths }).includes(
      "complete gate requires every baseline to be captured",
    ),
  );
});

test("optimization gate rejects unowned, multiply owned, and unknown proof paths", () => {
  assert.ok(
    validateOptimizationGate({
      manifest,
      schema,
      scripts,
      trackedPaths: [...trackedPaths, "unknown/file.txt"],
    }).includes("unowned tracked path: unknown/file.txt"),
  );

  const overlapping = structuredClone(manifest);
  overlapping.surfaces[0].prefixes.push(".github/");
  assert.ok(
    validateOptimizationGate({ manifest: overlapping, schema, scripts, trackedPaths }).some((error) =>
      error.startsWith("multiply owned tracked path: .github/workflows/ci.yml"),
    ),
  );

  const unknownProof = structuredClone(manifest);
  unknownProof.surfaces[0].proofCommands = ["npm run missing:proof"];
  assert.ok(
    validateOptimizationGate({ manifest: unknownProof, schema, scripts, trackedPaths }).includes(
      "repository-root: unknown proof command: npm run missing:proof",
    ),
  );
});

test("inventory assigns canonical owner and consumers independently from authorization state", () => {
  const inventory = buildOptimizationGateInventory({ manifest, trackedPaths });
  assert.deepEqual(inventory[0], {
    path: "package.json",
    surface: "repository-root",
    owner: "Repository maintainers",
    consumers: ["contributors", "release controls"],
  });
  assert.equal(manifest.authorization.status, "pending");
  assert.deepEqual(buildOptimizationGateInventory({ manifest: authorizedFixture(), trackedPaths }), inventory);
});

test("resolved findings do not require deferred-only expiry metadata", () => {
  const resolved = structuredClone(manifest);
  resolved.findings.push({ id: "OPT-001", status: "resolved", owner: "Repository maintainers", rationale: "Fixed." });
  assert.deepEqual(validateOptimizationGate({ manifest: resolved, schema, scripts, trackedPaths }), []);
});

test("complete gates reject deferred release-blocking findings", () => {
  const complete = authorizedFixture();
  complete.state = "complete";
  for (const baseline of complete.baselines) baseline.status = "captured";
  complete.findings = [
    {
      id: "OPT-999",
      status: "deferred",
      owner: "Test owner",
      rationale: "Deliberate release blocker.",
      expiry: "2026-12-31T23:59:59Z",
      releaseImpact: "blocking",
    },
  ];
  assert.ok(
    validateOptimizationGate({ manifest: complete, schema, scripts, trackedPaths }).includes(
      "complete gate cannot retain deferred release-blocking findings",
    ),
  );
});
